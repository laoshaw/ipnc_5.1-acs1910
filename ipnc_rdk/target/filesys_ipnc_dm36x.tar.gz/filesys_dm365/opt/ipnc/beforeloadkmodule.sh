/opt/ipnc/modules/init.d_ins/mountall.sh
