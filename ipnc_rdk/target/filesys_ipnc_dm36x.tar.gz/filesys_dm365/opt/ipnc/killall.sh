killall -2 Appro_avi_save
killall -9 audio-receiver
killall -2 wis-streamer
sleep 2
killall -9 wis-streamer
killall -9 boa
killall -9 upnp-scanip
killall -9 dhcpcd
killall -2 av_server.out 
killall -9 system_server
