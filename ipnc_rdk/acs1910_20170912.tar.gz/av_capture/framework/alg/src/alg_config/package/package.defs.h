/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-u17
 */

#ifndef alg_config__
#define alg_config__



#endif /* alg_config__ */ 
