{
    "server algorithms": {
        "programName": "alg_server.xv5T",
        "algs": [
        ],
    },
}
