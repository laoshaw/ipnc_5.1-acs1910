

#include <alg_crypto.h>


void *ALG_encryptCreate(ALG_CryptoCreate *create)
{

  return NULL;
}

int   ALG_encryptRun(void *hndl, Uint8 *inAddr, Uint8 *outAddr, Uint32 size)
{

  return 0;
}

int   ALG_encryptDelete(void *hndl)
{

  return 0;
}

