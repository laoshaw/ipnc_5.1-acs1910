#include "alg_aewb_priv.h"
#include "alg_ti_aewb_priv.h"
#include "alg_ti_flicker_detect.h"
#include "ae_ti.h"
#include "awb_ti.h"
#include "TI_aewb.h"


int TI_fd_get_config(int sensorMode, int* row_time, int* pinp, int* h3aWinHeight)
{
    int fd_res_support = 1;

    /* multi-resolution flicker detection support */
    if(sensorMode == DRV_IMGS_SENSOR_MODE_720x480)
    {
        /* D1 */
        *row_time = 47;
        *pinp = 60;
        *h3aWinHeight = 14;
    }
    else if (sensorMode == DRV_IMGS_SENSOR_MODE_1280x720)
    {
        /* 720p30 & 720p60*/
        *row_time = 44;
        *pinp = 72;
        *h3aWinHeight = 22;
    }
    else if (sensorMode == DRV_IMGS_SENSOR_MODE_1920x1080)
    {
        /* 1080p */
        *row_time = 29;
        *pinp = 42;
        *h3aWinHeight = 34;
    }
    else if (sensorMode == DRV_IMGS_SENSOR_MODE_1280x960)
    {
        /* SXVGA */
        *row_time = 34;
        *pinp = 56;
        *h3aWinHeight = 30;
    }
    else if (sensorMode == DRV_IMGS_SENSOR_MODE_1600x1200)
    {
        /* 2MP */
        *row_time = 26;
        *pinp = 44;
        *h3aWinHeight = 38;
    }
    else if (sensorMode == DRV_IMGS_SENSOR_MODE_2048x1536)
    {
        /* 3MP */
        *row_time = 31;
        *pinp = 30;
        *h3aWinHeight = 48;
    }
    else if (sensorMode == DRV_IMGS_SENSOR_MODE_2592x1920)
    {
        /* 5MP */
        *row_time = 36;
        *pinp = 24;
        *h3aWinHeight = 60;
    }
    else
    {
        /* FD resolution not currently supported, turn off FD */
        fd_res_support = 0;
    }

    return fd_res_support;
}

#define FD_BRIGHTNESS_THRESHHOLD 	(8333.0*1000*1024) 	// threshold value to be crossed to trigger FD detection process

int TI_fd_trigger(IAEWB_Ae *curAe, IAEWB_Ae *nextAe)
{
    int fd_trigger = 0;
    float FD_brightness_cur;
    float FD_brightness_next;

    FD_brightness_cur = (float)curAe->exposureTime * curAe->sensorGain * curAe->ipipeGain;
    FD_brightness_next = (float)nextAe->exposureTime * nextAe->sensorGain * nextAe->ipipeGain;

    /* Trigger Flicker detection process based on brightness threshold being crossed */
    if(FD_brightness_next < FD_BRIGHTNESS_THRESHHOLD && FD_brightness_cur >= FD_BRIGHTNESS_THRESHHOLD)
    {
        fd_trigger = 1; //Go bright
    }

    return fd_trigger;
}

