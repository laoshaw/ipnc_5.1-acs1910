
#include "alg_aewb_priv.h"
#include "TI_aewb.h"
#include "drv_ipipe.h"


int TI_2A_ISP_control(int eTime, int aGain, int dGain, int cTemp)
{
    return 0;
}







