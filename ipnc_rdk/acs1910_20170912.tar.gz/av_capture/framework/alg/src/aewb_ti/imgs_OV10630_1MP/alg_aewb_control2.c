
#include "alg_aewb_priv.h"

void ALG_aewbSetExposureGain(int EX, int AG, int DG, int init)
{
}  

