#ifndef _ALG_UTILS_H_
#define _ALG_UTILS_H_

#include <osa.h>
#include <drv.h>

int checkMinMax(int value, int min, int max);

#endif
