/*
 * Copyright (C) 2013 Texas Instruments Incorporated - http://www.ti.com/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <csl_ipipeifIoctl.h>


CSL_Status CSL_ipipeifOpen(CSL_IpipeifHandle hndl)
{
  if (hndl == NULL)
    return CSL_EINVPARAMS;

  hndl->regs = CSL_sysGetBaseAddr(CSL_MODULE_IPIPEIF);

  if (hndl->regs == NULL)
    return CSL_EFAIL;

  return CSL_SOK;
}

CSL_Status CSL_ipipeifClose(CSL_IpipeifHandle hndl)
{
  return CSL_SOK;
}

CSL_Status CSL_ipipeifInit(CSL_IpipeifHandle hndl)
{
  CSL_Status status = CSL_SOK;

  if (hndl == NULL)
    return CSL_EINVPARAMS;

  status |= CSL_ipipeifOpen(hndl);

  return status;
}

CSL_Status CSL_ipipeifExit(CSL_IpipeifHandle hndl)
{
  if (hndl == NULL)
    return CSL_EINVPARAMS;

  CSL_ipipeifClose(hndl);

  return CSL_SOK;
}
