/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef charlie_sqrtlib_samples__
#define charlie_sqrtlib_samples__



#endif /* charlie_sqrtlib_samples__ */ 
