/*
 *  ======== acme/utils/Bench.h ========
 *
 *  DO NOT MODIFY THIS FILE
 *
 *  It is generated from acme/utils/Bench.xdc and any changes may be overwritten.
 */

#ifdef acme_utils_Bench___EXTERNAL_SYNOPSIS
#error do not compile!!


    #include <acme/utils/Bench.h>

    /* -------- module-wide configs -------- */

    Bool Bench_enableFlag;

    /* -------- module-wide functions -------- */

    Void Bench_begin( String msg );
    Void Bench_end( );


#endif /* acme_utils_Bench___EXTERNAL_SYNOPSIS */



#ifdef acme_utils_Bench___INTERNAL_SYNOPSIS
#error do not compile!!


    #include "package/internal/Bench.xdc.h"

    /* -------- module-wide state -------- */

    typedef struct {
        String beginMsg;
        Int beginClock;
        Int overhead;
    } Bench_Module_State;

    extern Bench_Module_State Bench_module;
    static Bench_Module_State* const module = &Bench_module;

    /* -------- module-wide startup -------- */

    Int Bench_Module_startup( Int state );


#endif /* acme_utils_Bench___INTERNAL_SYNOPSIS */







#ifdef __cplusplus
#define __extern extern "C"
#else
#define __extern extern
#endif

#define acme_utils_Bench___VERS 102

#ifndef xdc_std__include
#ifndef __nested__
#define __nested__
#include <xdc/std.h>
#undef __nested__
#else
#include <xdc/std.h>
#endif
#endif

#ifndef XDC__
#include <xdc/runtime/xdc.h>
#endif
#ifndef xdc_runtime_Types__include
#ifndef __nested__
#define __nested__
#include <xdc/runtime/Types.h>
#undef __nested__
#else
#include <xdc/runtime/Types.h>
#endif
#endif

#ifndef acme_utils_Bench__include
#define acme_utils_Bench__include

#ifndef acme_utils__
#include <acme/utils/package/package.defs.h>
#endif

#ifndef xdc_runtime_IModule__include
#ifndef __nested__
#define __nested__
#include <xdc/runtime/IModule.h>
#undef __nested__
#else
#include <xdc/runtime/IModule.h>
#endif
#endif


/* auxiliary definitions */

/* module state fields */
#define acme_utils_Bench___MODULE_FLDS \
    xdc_String beginMsg;\
    xdc_Int beginClock;\
    xdc_Int overhead;\


/* internal definitions */

/* module-wide configs */
typedef xdc_Bits32 CT__acme_utils_Bench_Module__diagsEnabled;
typedef xdc_Bits32 CT__acme_utils_Bench_Module__diagsIncluded;
typedef xdc_Bits16* CT__acme_utils_Bench_Module__diagsMask;
typedef xdc_Ptr CT__acme_utils_Bench_Module__gateObj;
typedef xdc_Ptr CT__acme_utils_Bench_Module__gatePrms;
typedef xdc_runtime_Types_ModuleId CT__acme_utils_Bench_Module__id;
typedef xdc_Bool CT__acme_utils_Bench_Module__loggerDefined;
typedef xdc_Ptr CT__acme_utils_Bench_Module__loggerObj;
typedef xdc_runtime_Types_LoggerFxn4 CT__acme_utils_Bench_Module__loggerFxn4;
typedef xdc_runtime_Types_LoggerFxn8 CT__acme_utils_Bench_Module__loggerFxn8;
typedef xdc_Bool (*CT__acme_utils_Bench_Module__startupDoneFxn)(void);
typedef xdc_Int CT__acme_utils_Bench_Object__count;
typedef xdc_runtime_IHeap_Handle CT__acme_utils_Bench_Object__heap;
typedef xdc_SizeT CT__acme_utils_Bench_Object__sizeof;
typedef xdc_Ptr CT__acme_utils_Bench_Object__table;
typedef xdc_Bool CT__acme_utils_Bench_enableFlag;
__extern __FAR__ const CT__acme_utils_Bench_Module__diagsEnabled acme_utils_Bench_Module__diagsEnabled__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__diagsIncluded acme_utils_Bench_Module__diagsIncluded__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__diagsMask acme_utils_Bench_Module__diagsMask__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__gateObj acme_utils_Bench_Module__gateObj__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__gatePrms acme_utils_Bench_Module__gatePrms__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__id acme_utils_Bench_Module__id__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__loggerDefined acme_utils_Bench_Module__loggerDefined__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__loggerObj acme_utils_Bench_Module__loggerObj__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__loggerFxn4 acme_utils_Bench_Module__loggerFxn4__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__loggerFxn8 acme_utils_Bench_Module__loggerFxn8__C;
__extern __FAR__ const CT__acme_utils_Bench_Module__startupDoneFxn acme_utils_Bench_Module__startupDoneFxn__C;
__extern __FAR__ const CT__acme_utils_Bench_Object__count acme_utils_Bench_Object__count__C;
__extern __FAR__ const CT__acme_utils_Bench_Object__heap acme_utils_Bench_Object__heap__C;
__extern __FAR__ const CT__acme_utils_Bench_Object__sizeof acme_utils_Bench_Object__sizeof__C;
__extern __FAR__ const CT__acme_utils_Bench_Object__table acme_utils_Bench_Object__table__C;
__extern __FAR__ const CT__acme_utils_Bench_enableFlag acme_utils_Bench_enableFlag__C;
#define acme_utils_Bench_enableFlag (acme_utils_Bench_enableFlag__C)

/* rom dispatch */
#define acme_utils_Bench___MODULE_FXNS \
    xdc_Void (*begin)(xdc_String);\
    xdc_Void (*end)(void);\


/* function declarations */
xdc__CODESECT(acme_utils_Bench_Module_startup__E, "acme_utils_Bench_Module_startup")
__extern xdc_Int acme_utils_Bench_Module_startup__E( xdc_Int state );
xdc__CODESECT(acme_utils_Bench_Module_startup__F, "acme_utils_Bench_Module_startup")
__extern xdc_Int acme_utils_Bench_Module_startup__F( xdc_Int state );
xdc__CODESECT(acme_utils_Bench_Module_startup__R, "acme_utils_Bench_Module_startup")
__extern xdc_Int acme_utils_Bench_Module_startup__R( xdc_Int state );
#define acme_utils_Bench_Module_startup acme_utils_Bench_Module_startup__E
xdc__CODESECT(acme_utils_Bench_Handle__label__S, "acme_utils_Bench_Handle__label")
__extern xdc_runtime_Types_Label* acme_utils_Bench_Handle__label__S( xdc_Ptr obj, xdc_runtime_Types_Label* lab );
xdc__CODESECT(acme_utils_Bench_Module__startupDone__S, "acme_utils_Bench_Module__startupDone")
__extern xdc_Bool acme_utils_Bench_Module__startupDone__S( void );
xdc__CODESECT(acme_utils_Bench_Object__create__S, "acme_utils_Bench_Object__create")
__extern xdc_Ptr acme_utils_Bench_Object__create__S( xdc_Ptr __oa, xdc_SizeT __osz, xdc_Ptr __aa, const xdc_UChar* __pa, xdc_SizeT __psz, xdc_runtime_Error_Block* __eb );
xdc__CODESECT(acme_utils_Bench_Object__delete__S, "acme_utils_Bench_Object__delete")
__extern xdc_Void acme_utils_Bench_Object__delete__S( xdc_Ptr instp );
xdc__CODESECT(acme_utils_Bench_Object__destruct__S, "acme_utils_Bench_Object__destruct")
__extern xdc_Void acme_utils_Bench_Object__destruct__S( xdc_Ptr objp );
xdc__CODESECT(acme_utils_Bench_Object__get__S, "acme_utils_Bench_Object__get")
__extern xdc_Ptr acme_utils_Bench_Object__get__S( xdc_Ptr oarr, xdc_Int i );
xdc__CODESECT(acme_utils_Bench_Object__first__S, "acme_utils_Bench_Object__first")
__extern xdc_Ptr acme_utils_Bench_Object__first__S( void );
xdc__CODESECT(acme_utils_Bench_Object__next__S, "acme_utils_Bench_Object__next")
__extern xdc_Ptr acme_utils_Bench_Object__next__S( xdc_Ptr obj );
xdc__CODESECT(acme_utils_Bench_Params__init__S, "acme_utils_Bench_Params__init")
__extern xdc_Void acme_utils_Bench_Params__init__S( xdc_Ptr dst, xdc_Ptr src, xdc_SizeT psz, xdc_SizeT isz );
xdc__CODESECT(acme_utils_Bench_Proxy__abstract__S, "acme_utils_Bench_Proxy__abstract")
__extern xdc_Bool acme_utils_Bench_Proxy__abstract__S( void );
xdc__CODESECT(acme_utils_Bench_Proxy__delegate__S, "acme_utils_Bench_Proxy__delegate")
__extern xdc_Ptr acme_utils_Bench_Proxy__delegate__S( void );
#define acme_utils_Bench_begin acme_utils_Bench_begin__E
xdc__CODESECT(acme_utils_Bench_begin__E, "acme_utils_Bench_begin")
__extern xdc_Void acme_utils_Bench_begin__E( xdc_String msg );
xdc__CODESECT(acme_utils_Bench_begin__F, "acme_utils_Bench_begin")
__extern xdc_Void acme_utils_Bench_begin__F( xdc_String msg );
__extern xdc_Void acme_utils_Bench_begin__R( xdc_String msg );
#define acme_utils_Bench_end acme_utils_Bench_end__E
xdc__CODESECT(acme_utils_Bench_end__E, "acme_utils_Bench_end")
__extern xdc_Void acme_utils_Bench_end__E( void );
xdc__CODESECT(acme_utils_Bench_end__F, "acme_utils_Bench_end")
__extern xdc_Void acme_utils_Bench_end__F( void );
__extern xdc_Void acme_utils_Bench_end__R( void );

/* system functions */
#define acme_utils_Bench_Module_startupDone() acme_utils_Bench_Module__startupDone__S()
static inline CT__acme_utils_Bench_Module__id acme_utils_Bench_Module_id(void) {
    return acme_utils_Bench_Module__id__C;
}

#endif /* acme_utils_Bench__include */

/* __prefix alises */
#if !defined(__nested__) && !defined(acme_utils_Bench__nolocalnames)
#define Bench_Module_State acme_utils_Bench_Module_State
#define Bench_enableFlag acme_utils_Bench_enableFlag
#define Bench_begin acme_utils_Bench_begin
#define Bench_end acme_utils_Bench_end
#define Bench_Module_name acme_utils_Bench_Module_name
#define Bench_Module_id acme_utils_Bench_Module_id
#define Bench_Module_startup acme_utils_Bench_Module_startup
#define Bench_Module_startupDone acme_utils_Bench_Module_startupDone
#endif


