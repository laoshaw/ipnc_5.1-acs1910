#ifndef acme_utils__
#define acme_utils__


/*
 * ======== module acme.utils.Bench ========
 */

typedef struct acme_utils_Bench_Module_State acme_utils_Bench_Module_State;
#endif /* acme_utils__ */ 
