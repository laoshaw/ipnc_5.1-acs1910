#include <xdc/std.h>
#ifndef __config__
__FAR__ char acme_utils__dummy__;
#define __xdc_PKGVERS null
#define __xdc_PKGNAME acme.utils
#define __xdc_PKGPREFIX acme_utils_
#ifdef __xdc_bld_pkg_c__
#define __stringify(a) #a
#define __local_include(a) __stringify(a)
#include __local_include(__xdc_bld_pkg_c__)
#endif

#else
#ifdef acme_utils_Bench___used
/*
 *  ======== module Bench ========
 *  Do not modify this file; it is generated from the specification Bench.xdc
 *  and any modifications risk being overwritten.
 */

#ifndef acme_utils_Bench__include
#ifndef __nested__
#define __nested__
#include <acme/utils/Bench.h>
#undef __nested__
#else
#include <acme/utils/Bench.h>
#endif
#endif

#if defined(xdc_runtime_Log__include) && defined(acme_utils_Bench___LOGOBJ) && acme_utils_Bench___DGSINCL & 0x1
#define acme_utils_Bench___L_ENTRY 1
#else
#define acme_utils_Bench___L_ENTRY 0
#endif
#if defined(xdc_runtime_Log__include) && defined(acme_utils_Bench___LOGOBJ) && acme_utils_Bench___DGSINCL & 0x2
#define acme_utils_Bench___L_EXIT 1
#else
#define acme_utils_Bench___L_EXIT 0
#endif
#if defined(xdc_runtime_Log__include) && defined(acme_utils_Bench___LOGOBJ) && acme_utils_Bench___DGSINCL & 0x4
#define acme_utils_Bench___L_LIFECYCLE 1
#else
#define acme_utils_Bench___L_LIFECYCLE 0
#endif

#ifndef __isrom__ /* acme_utils_Bench_ */

#undef Module__MID
#define Module__MID acme_utils_Bench_Module__id__C
#undef Module__DGSINCL
#define Module__DGSINCL acme_utils_Bench_Module__diagsIncluded__C
#undef Module__DGSENAB
#define Module__DGSENAB acme_utils_Bench_Module__diagsEnabled__C
#undef Module__DGSMASK
#define Module__DGSMASK acme_utils_Bench_Module__diagsMask__C
#undef Module__LOGDEF
#define Module__LOGDEF acme_utils_Bench_Module__loggerDefined__C
#undef Module__LOGOBJ
#define Module__LOGOBJ acme_utils_Bench_Module__loggerObj__C
#undef Module__LOGFXN4
#define Module__LOGFXN4 acme_utils_Bench_Module__loggerFxn4__C
#undef Module__LOGFXN8
#define Module__LOGFXN8 acme_utils_Bench_Module__loggerFxn8__C
#undef Module__G_OBJ
#define Module__G_OBJ acme_utils_Bench_Module__gateObj__C
#undef Module__G_PRMS
#define Module__G_PRMS acme_utils_Bench_Module__gatePrms__C
#undef Module__GP_create
#define Module__GP_create acme_utils_Bench_Module_GateProxy_create
#undef Module__GP_delete
#define Module__GP_delete acme_utils_Bench_Module_GateProxy_delete
#undef Module__GP_enter
#define Module__GP_enter acme_utils_Bench_Module_GateProxy_enter
#undef Module__GP_leave
#define Module__GP_leave acme_utils_Bench_Module_GateProxy_leave
#undef Module__GP_query
#define Module__GP_query acme_utils_Bench_Module_GateProxy_query
#if acme_utils_Bench___scope != -1 || defined(acme_utils_Bench_begin__PATCH)
#undef __FN__
#ifdef acme_utils_Bench_begin__PATCH
#define __FN__ acme_utils_Bench_begin__PATCH
#else
#define __FN__ acme_utils_Bench_begin__F
#endif
xdc_Void acme_utils_Bench_begin__E( xdc_String msg ) {
#if acme_utils_Bench___L_ENTRY
    xdc_runtime_Log_write1(acme_utils_Bench_begin__ENTRY_EVT, (xdc_IArg)msg);
#endif
#if acme_utils_Bench___L_EXIT
    __FN__(msg);
    xdc_runtime_Log_write1(acme_utils_Bench_begin__EXIT_EVT, 0);
#else
    __FN__(msg);
#endif
}
#endif
#if acme_utils_Bench___scope != -1 || defined(acme_utils_Bench_end__PATCH)
#undef __FN__
#ifdef acme_utils_Bench_end__PATCH
#define __FN__ acme_utils_Bench_end__PATCH
#else
#define __FN__ acme_utils_Bench_end__F
#endif
xdc_Void acme_utils_Bench_end__E( void ) {
#if acme_utils_Bench___L_ENTRY
    xdc_runtime_Log_write0(acme_utils_Bench_end__ENTRY_EVT);
#endif
#if acme_utils_Bench___L_EXIT
    __FN__();
    xdc_runtime_Log_write1(acme_utils_Bench_end__EXIT_EVT, 0);
#else
    __FN__();
#endif
}
#endif
#if acme_utils_Bench___scope != -1
xdc_Int acme_utils_Bench_Module_startup__E( xdc_Int state ) { return acme_utils_Bench_Module_startup__F(state); }
#endif

#if defined(acme_utils_Bench___EXPORT) && defined(__ti__)
#if acme_utils_Bench___scope != -1
#pragma FUNC_EXT_CALLED(acme_utils_Bench_Module__startupDone__S);
#pragma FUNC_EXT_CALLED(acme_utils_Bench_Module_startup__E);
#endif
#pragma FUNC_EXT_CALLED(acme_utils_Bench_begin__E);
#pragma FUNC_EXT_CALLED(acme_utils_Bench_end__E);
#endif

#if defined(acme_utils_Bench___used) && defined(__GNUC__)

#if __GNUC__ >= 4
const CT__acme_utils_Bench_Module__diagsEnabled acme_utils_Bench_Module__diagsEnabled__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__diagsIncluded acme_utils_Bench_Module__diagsIncluded__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__diagsMask acme_utils_Bench_Module__diagsMask__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__gateObj acme_utils_Bench_Module__gateObj__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__gatePrms acme_utils_Bench_Module__gatePrms__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__id acme_utils_Bench_Module__id__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__loggerDefined acme_utils_Bench_Module__loggerDefined__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__loggerObj acme_utils_Bench_Module__loggerObj__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__loggerFxn4 acme_utils_Bench_Module__loggerFxn4__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__loggerFxn8 acme_utils_Bench_Module__loggerFxn8__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Module__startupDoneFxn acme_utils_Bench_Module__startupDoneFxn__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Object__count acme_utils_Bench_Object__count__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Object__heap acme_utils_Bench_Object__heap__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Object__sizeof acme_utils_Bench_Object__sizeof__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_Object__table acme_utils_Bench_Object__table__C __attribute__ ((externally_visible));
const CT__acme_utils_Bench_enableFlag acme_utils_Bench_enableFlag__C __attribute__ ((externally_visible));
xdc_runtime_Types_Label* acme_utils_Bench_Handle__label__S( xdc_Ptr obj, xdc_runtime_Types_Label* lab ) __attribute__ ((externally_visible));
xdc_Bool acme_utils_Bench_Module__startupDone__S( void ) __attribute__ ((externally_visible));
xdc_Ptr acme_utils_Bench_Object__create__S( xdc_Ptr __oa, xdc_SizeT __osz, xdc_Ptr __aa, const xdc_UChar* __pa, xdc_SizeT __psz, xdc_runtime_Error_Block* __eb ) __attribute__ ((externally_visible));
xdc_Void acme_utils_Bench_Object__delete__S( xdc_Ptr instp ) __attribute__ ((externally_visible));
xdc_Void acme_utils_Bench_Object__destruct__S( xdc_Ptr objp ) __attribute__ ((externally_visible));
xdc_Ptr acme_utils_Bench_Object__get__S( xdc_Ptr oarr, xdc_Int i ) __attribute__ ((externally_visible));
xdc_Ptr acme_utils_Bench_Object__first__S( void ) __attribute__ ((externally_visible));
xdc_Ptr acme_utils_Bench_Object__next__S( xdc_Ptr obj ) __attribute__ ((externally_visible));
xdc_Void acme_utils_Bench_Params__init__S( xdc_Ptr dst, xdc_Ptr src, xdc_SizeT psz, xdc_SizeT isz ) __attribute__ ((externally_visible));
xdc_Bool acme_utils_Bench_Proxy__abstract__S( void ) __attribute__ ((externally_visible));
xdc_Ptr acme_utils_Bench_Proxy__delegate__S( void ) __attribute__ ((externally_visible));
xdc_Void acme_utils_Bench_begin__E( xdc_String msg ) __attribute__ ((externally_visible));
xdc_Void acme_utils_Bench_end__E( void ) __attribute__ ((externally_visible));
#endif
#endif
#ifdef acme_utils_Bench___ROMPATCH
__FAR__ acme_utils_Bench_Module__MTAB__C__qual acme_utils_Bench_MTab__ acme_utils_Bench_Module__MTAB__C = {
#if acme_utils_Bench___scope == -1
    acme_utils_Bench_begin__E,
    acme_utils_Bench_end__E,
#endif
0
};
#endif

#else /* __isrom__ acme_utils_Bench_ */

#undef Module__MID
#define Module__MID acme_utils_Bench_Module__id__C
#undef Module__DGSINCL
#define Module__DGSINCL acme_utils_Bench_Module__diagsIncluded__C
#undef Module__DGSENAB
#define Module__DGSENAB acme_utils_Bench_Module__diagsEnabled__C
#undef Module__DGSMASK
#define Module__DGSMASK acme_utils_Bench_Module__diagsMask__C
#undef Module__LOGDEF
#define Module__LOGDEF acme_utils_Bench_Module__loggerDefined__C
#undef Module__LOGOBJ
#define Module__LOGOBJ acme_utils_Bench_Module__loggerObj__C
#undef Module__LOGFXN4
#define Module__LOGFXN4 acme_utils_Bench_Module__loggerFxn4__C
#undef Module__LOGFXN8
#define Module__LOGFXN8 acme_utils_Bench_Module__loggerFxn8__C
#undef Module__G_OBJ
#define Module__G_OBJ acme_utils_Bench_Module__gateObj__C
#undef Module__G_PRMS
#define Module__G_PRMS acme_utils_Bench_Module__gatePrms__C
#undef Module__GP_create
#define Module__GP_create acme_utils_Bench_Module_GateProxy_create
#undef Module__GP_delete
#define Module__GP_delete acme_utils_Bench_Module_GateProxy_delete
#undef Module__GP_enter
#define Module__GP_enter acme_utils_Bench_Module_GateProxy_enter
#undef Module__GP_leave
#define Module__GP_leave acme_utils_Bench_Module_GateProxy_leave
#undef Module__GP_query
#define Module__GP_query acme_utils_Bench_Module_GateProxy_query
#undef __FN__
#ifdef acme_utils_Bench___ROMPATCH
#define __FN__ acme_utils_Bench_Module__MTAB__C.begin
#else
#define __FN__ acme_utils_Bench_begin__F
#endif
xdc_Void acme_utils_Bench_begin__E( xdc_String msg ) {
    __FN__(msg);
}
#undef __FN__
#ifdef acme_utils_Bench___ROMPATCH
#define __FN__ acme_utils_Bench_Module__MTAB__C.end
#else
#define __FN__ acme_utils_Bench_end__F
#endif
xdc_Void acme_utils_Bench_end__E( void ) {
    __FN__();
}
#if acme_utils_Bench___scope != -1
xdc_Int acme_utils_Bench_Module_startup__E( xdc_Int state ) { return acme_utils_Bench_Module_startup__F(state); }
#endif
#undef __FN__
#define __FN__ acme_utils_Bench_begin__F
xdc_Void acme_utils_Bench_begin__R( xdc_String msg ) {
#if acme_utils_Bench___L_ENTRY
    xdc_runtime_Log_write1(acme_utils_Bench_begin__ENTRY_EVT, (xdc_IArg)msg);
#endif
#if acme_utils_Bench___L_EXIT
    __FN__(msg);
    xdc_runtime_Log_write1(acme_utils_Bench_begin__EXIT_EVT, 0);
#else
    __FN__(msg);
#endif
}
#undef __FN__
#define __FN__ acme_utils_Bench_end__F
xdc_Void acme_utils_Bench_end__R( void ) {
#if acme_utils_Bench___L_ENTRY
    xdc_runtime_Log_write0(acme_utils_Bench_end__ENTRY_EVT);
#endif
#if acme_utils_Bench___L_EXIT
    __FN__();
    xdc_runtime_Log_write1(acme_utils_Bench_end__EXIT_EVT, 0);
#else
    __FN__();
#endif
}

#if defined(acme_utils_Bench___EXPORT) && defined(__ti__)
#if acme_utils_Bench___scope != -1
#pragma FUNC_EXT_CALLED(acme_utils_Bench_Module__startupDone__S);
#pragma FUNC_EXT_CALLED(acme_utils_Bench_Module_startup__E);
#endif
#pragma FUNC_EXT_CALLED(acme_utils_Bench_begin__R);
#pragma FUNC_EXT_CALLED(acme_utils_Bench_end__R);
#endif
#endif /* __isrom__ */

#if acme_utils_Bench___scope != -1
xdc_Bool acme_utils_Bench_Module__startupDone__S(void) {

    return acme_utils_Bench_Module__startupDone__F();
}
#endif /* acme_utils_Bench___scope */

#endif /* acme_utils_Bench___used */


#endif
