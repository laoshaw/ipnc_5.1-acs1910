/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef charlie_sqrtlib__
#define charlie_sqrtlib__



#endif /* charlie_sqrtlib__ */ 
