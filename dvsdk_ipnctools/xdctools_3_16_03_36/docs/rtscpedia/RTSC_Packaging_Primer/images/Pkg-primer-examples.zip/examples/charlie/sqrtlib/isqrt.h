/*
 *  ======== charlie/sqrtlib/isqrt.h ========
 */

extern unsigned int isqrt( unsigned long val );
