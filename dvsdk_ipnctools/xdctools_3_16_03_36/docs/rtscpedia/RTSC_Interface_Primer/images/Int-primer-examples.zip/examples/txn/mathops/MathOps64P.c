/*
 *  ======== txn/mathops/MathOps64P.c ========
 */

#include "package/internal/MathOps64P.xdc.h"
 
#include <c6x.h>        /* declares TMS32064+ intrinsics */
 
Int32 MathOps64P_mpy(Int32 x, Int32 y)
{
    return _mpy(x, y);
}
 
Int32 MathOps64P_mpyh(Int32 x, Int32 y)
{
    return _mpyh(x, y);
}
 
Int32 MathOps64P_mpyhl(Int32 x, Int32 y)
{
    return _mpyhl(x, y);
}
 
Int32 MathOps64P_mpylh(Int32 x, Int32 y)
{
    return _mpylh(x, y);
}
