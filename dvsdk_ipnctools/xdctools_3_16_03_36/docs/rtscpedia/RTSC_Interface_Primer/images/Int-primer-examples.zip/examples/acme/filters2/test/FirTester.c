/*
 *  ======== acme/filters2/test/FirTester.c ========
 */

#include <acme/utils2/Bench.h>
#include <xdc/runtime/System.h>
#include "package/internal/FirTester.xdc.h"
 
#define COEFFSLEN 4
#define FRAMELEN 20
 
static Int16 coeffs[COEFFSLEN] = {20000, 21000, 22000, -3000}; 
 
static Int16 inFrame[FRAMELEN] = {0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9};
static Int16 outFrame[FRAMELEN];
 
static Void printOut();
 
Int FirTester_main(Int argc, Char* argv[])
{
    FirTester_PFir_Handle fir;
    FirTester_PFir_Params params;
 
    FirTester_PFir_Params_init(&params);
    params.frameLen = FRAMELEN;
 
    fir = FirTester_PFir_create(coeffs, COEFFSLEN, &params, NULL);  /* create filter */
    Bench_begin(FirTester_benchMsg);                                /* start benchmark */
    FirTester_PFir_apply(fir, inFrame, outFrame);                   /* run filter */
    Bench_end();                                                    /* stop and display timing */
    printOut();                                                     /* display results */
    FirTester_PFir_delete(&fir);                                    /* delete filter */
 
    return 0;
}
 
static Void printOut()
{
    Int i;
    String comma = "";
 
    System_printf("\toutFrame = {");
    for (i = 0; i < FRAMELEN; i++) {
        System_printf("%s%d", comma, outFrame[i]);
        comma = ",";
    }
    System_printf("}\n\n");
}
