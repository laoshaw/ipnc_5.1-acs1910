/*
 *  ======== bravo/math2/test/SineGenTest1.c ========
 */

#include <bravo/math2/SineGen.h>
#include <xdc/runtime/System.h>
 
#define COUNT 16
 
Int main()
{
    SineGen_Handle sgInst;
    SineGen_Params sgParams;
    Int i;
 
    SineGen_Params_init(&sgParams);
 
    sgParams.freq = 32;
    sgParams.rate = 1024;
    sgParams.range = 100;
    sgInst = SineGen_create(&sgParams, NULL);
 
    for (i = 0; i < COUNT; i++) {
        System_printf("%d ", SineGen_next(sgInst)); 
    }
    System_printf("\n");
 
    return 0;
}
