/*
 *  ======== stdsorg/math/MathOpsStd.c ========
 */

#include "package/internal/MathOpsStd.xdc.h"
 
Int32 MathOpsStd_mpy(Int32 x, Int32 y)
{
    return (Int16)(x) * (Int16)(y);
}
 
Int32 MathOpsStd_mpyh(Int32 x, Int32 y)
{
    return (Int16)((0xFFFF0000 & x) >> 16) * (Int16)((0xFFFF0000 & y) >> 16);
}
 
Int32 MathOpsStd_mpyhl(Int32 x, Int32 y)
{
    return (Int16)((0xFFFF0000 & x) >> 16) * (Int16)(y);
}
 
Int32 MathOpsStd_mpylh(Int32 x, Int32 y)
{
    return (Int16)(x) * (Int16)((0xFFFF0000 & y) >> 16);
}
