/*
 *  ======== bravo/math2/test/RandGenTest1.c ========
 */

#include <bravo/math2/RandGen.h>
#include <xdc/runtime/System.h>
 
#define COUNT 16
 
Int main()
{
    RandGen_Handle rgInst;
    RandGen_Params rgParams;
    Int i;
 
    RandGen_Params_init(&rgParams);
 
    rgParams.seed = 10;
    rgParams.range = 100;
    rgInst = RandGen_create(&rgParams, NULL);
 
    for (i = 0; i < COUNT; i++) {
        System_printf("%d ", RandGen_next(rgInst)); 
    }
    System_printf("\n");
 
    return 0;
}
