/*
 *  ======== bravo/math2/RandGen.c ========
 */

#include "package/internal/RandGen.xdc.h"
 
Void RandGen_Instance_init(RandGen_Object *obj, const RandGen_Params *params)
{
    obj->range = params->range;
    obj->next = params->seed;
}
 
Int16 RandGen_next(RandGen_Object *obj)
{
    /* randomize and retain the next sequence value */
    obj->next = obj->next * 1103515245 + 12345;
 
    /* scale the result to within the sequence's parameterized range */
    return (Int16)((obj->next / (RandGen_MAXVALUE + 1)) % ((ULong)obj->range + 1));
}
 
Void RandGen_nextn(RandGen_Object *obj, Int16 *buffer, Int count)
{
    Int i;
 
    /* fill the buffer through repeated calls to RandGen_next */
    for (i = 0; i < count; i++) {
        *buffer++ = RandGen_next(obj);
    }
}
