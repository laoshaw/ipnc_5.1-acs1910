/*
 *  ======== acme/filters2/FirC.c ========
 */

#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>
#include "package/internal/FirC.xdc.h"
 
#include <string.h>
 
static SizeT historySize(FirC_Object *obj)    /* helper function */
{
    return (obj->coeffsLen + obj->frameLen - 1) * sizeof (Int16);
}
 
Int FirC_Instance_init(FirC_Object *obj, Int16 coeffs[], Int coeffsLen,
                      const FirC_Params *params, Error_Block* eb)
{
    obj->coeffs = coeffs;
    obj->coeffsLen = coeffsLen;
    obj->frameLen = params->frameLen;
 
    obj->history = Memory_calloc(NULL, historySize(obj), 4, eb);
    return 0;
}
 
Void FirC_Instance_finalize(FirC_Object *obj, Int status)
{
    Memory_free(NULL, obj->history, historySize(obj));
}
 
Void FirC_apply(FirC_Object *obj, Int16 inFrame[], Int16 outFrame[])
{
    Int i, j;
    Int32 sum0, sum1;
 
    Int coeffsLen = obj->coeffsLen;
    Int frameLen = obj->frameLen;
 
    Int16 *history = obj->history;
    Int16 *coeffs = obj->coeffs;
 
    Int32 *history2 = (Int32 *)history;
    Int32 *coeffs2 = (Int32 *)coeffs;
 
    memcpy(&history[coeffsLen - 1], inFrame, frameLen * sizeof (Int16));
 
    for (j = 0; j < frameLen / 2; j++) {
        sum0 = sum1 = 0;
        for (i = 0; i < coeffsLen / 2; i++) {
            sum0 += FirC_PMathOps_mpy(history2[i + j], coeffs2[i]);
            sum0 += FirC_PMathOps_mpyh(history2[i + j], coeffs2[i]);
            sum1 += FirC_PMathOps_mpyhl(history2[i + j], coeffs2[i]);
            sum1 += FirC_PMathOps_mpylh(history2[i + j + 1], coeffs2[i]);
        }
        *outFrame++ = (Int16)(sum0 >> 15);
        *outFrame++ = (Int16)(sum1 >> 15);
    }
 
    memcpy(history, &history[frameLen], (coeffsLen - 1) * sizeof (Int16));    
}
