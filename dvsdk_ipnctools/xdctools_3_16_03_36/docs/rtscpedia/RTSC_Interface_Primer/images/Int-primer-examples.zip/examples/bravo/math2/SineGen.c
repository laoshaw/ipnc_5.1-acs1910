/*
 * ======== bravo/math2/SineGen.c ========
 */
 
#include "package/internal/SineGen.xdc.h"
 
Void SineGen_Instance_init(SineGen_Object *obj, const SineGen_Params *params)
{
    Int r;
 
    obj->shift = 15;
    for (r = params->range; r > 0; r >>= 1) {
        --obj->shift;
    }
 
    obj->step = SineGen_sineTabSize * params->freq / params->rate;
    obj->index = 0;
}
 
Int16 SineGen_next(SineGen_Object *obj)
{
    Int res;
 
    res = SineGen_sineTab[obj->index] >> (obj->shift);
    obj->index = (obj->index + obj->step) % SineGen_sineTabSize;
 
    return res;
}
 
Void SineGen_nextn(SineGen_Object *obj, Int16 *buffer, Int count)
{
    Int i;
 
    for (i = 0; i < count; i++) {
        *buffer++ = SineGen_next(obj);
    }
}
