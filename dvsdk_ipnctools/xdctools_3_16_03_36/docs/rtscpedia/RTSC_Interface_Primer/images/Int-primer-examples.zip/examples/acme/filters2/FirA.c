/*
 *  ======== acme/filters2/FirA.c ========
 */

#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>
#include "package/internal/FirA.xdc.h"
 
#include <string.h>
 
static SizeT historySize(FirA_Object *obj)    /* helper function */
{
    return (obj->coeffsLen + obj->frameLen - 1) * sizeof (Int16);
}
 
Int FirA_Instance_init(FirA_Object *obj, Int16 coeffs[], Int coeffsLen,
                      const FirA_Params *params, Error_Block* eb)
{
    obj->coeffs = coeffs;
    obj->coeffsLen = coeffsLen;
    obj->frameLen = params->frameLen;
 
    obj->history = Memory_calloc(NULL, historySize(obj), 4, eb);
    return 0;
}
 
Void FirA_Instance_finalize(FirA_Object *obj, Int status)
{
    Memory_free(NULL, obj->history, historySize(obj));
}
 
Void FirA_apply(FirA_Object *obj, Int16 inFrame[], Int16 outFrame[])
{
    Int i, j;
    Int32 sum;
 
    Int coeffsLen = obj->coeffsLen;
    Int frameLen = obj->frameLen;
 
    Int16 *history = obj->history;
    Int16 *coeffs = obj->coeffs;
 
    memcpy(&history[coeffsLen - 1], inFrame, frameLen * sizeof (Int16));
 
    for (j = 0; j < frameLen; j++) {
        sum = 0;
        for (i = 0; i < coeffsLen; i++) {
            sum += history[i + j] * coeffs[i];
        }
 
        *outFrame++ = (Int16)(sum >> 15);
    }
 
    memcpy(history, &history[frameLen], (coeffsLen - 1) * sizeof (Int16));    
}
