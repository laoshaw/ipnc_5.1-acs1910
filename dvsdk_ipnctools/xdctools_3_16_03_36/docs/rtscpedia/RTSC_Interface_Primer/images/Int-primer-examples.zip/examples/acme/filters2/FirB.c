/*
 *  ======== acme/filters2/FirB.c ========
 */

#include <xdc/runtime/Error.h>
#include <xdc/runtime/Memory.h>
#include "package/internal/FirB.xdc.h"
 
#include <string.h>
#include <c6x.h>       /* declares TMS32064+ intrinsics */
 
static SizeT historySize(FirB_Object *obj)    /* helper function */
{
    return (obj->coeffsLen + obj->frameLen - 1) * sizeof (Int16);
}
 
Int FirB_Instance_init(FirB_Object *obj, Int16 coeffs[], Int coeffsLen,
                      const FirB_Params *params, Error_Block* eb)
{
    obj->coeffs = coeffs;
    obj->coeffsLen = coeffsLen;
    obj->frameLen = params->frameLen;
 
    obj->history = Memory_calloc(NULL, historySize(obj), 4, eb);
    return 0;
}
 
Void FirB_Instance_finalize(FirB_Object *obj, Int status)
{
    Memory_free(NULL, obj->history, historySize(obj));
}
 
Void FirB_apply(FirB_Object *obj, Int16 inFrame[], Int16 outFrame[])
{
    Int i, j;
    Int32 sum0, sum1;
 
    Int coeffsLen = obj->coeffsLen;
    Int frameLen = obj->frameLen;
 
    Int16 *history = obj->history;
    Int16 *coeffs = obj->coeffs;
 
    Int32 *history2 = (Int32 *)history;
    Int32 *coeffs2 = (Int32 *)coeffs;
 
    memcpy(&history[coeffsLen - 1], inFrame, frameLen * sizeof (Int16));
 
    for (j = 0; j < frameLen / 2; j++) {
        sum0 = sum1 = 0;
        for (i = 0; i < coeffsLen / 2; i++) {
            sum0 += _mpy(history2[i + j], coeffs2[i]);
            sum0 += _mpyh(history2[i + j], coeffs2[i]);
            sum1 += _mpyhl(history2[i + j], coeffs2[i]);
            sum1 += _mpylh(history2[i + j + 1], coeffs2[i]);
        }
        *outFrame++ = (Int16)(sum0 >> 15);
        *outFrame++ = (Int16)(sum1 >> 15);
    }
 
    memcpy(history, &history[frameLen], (coeffsLen - 1) * sizeof (Int16));    
}
