/*
 *  ======== lesson3/prog.c ========
 */

#include <bravo/math/RandGen.h>
#include <xdc/runtime/System.h>
 
#define COUNT 10
 
Int main()
{
    RandGen_Handle rgInst;
    RandGen_Params rgParams;
    Int i;
 
    RandGen_Params_init(&rgParams);
 
    rgParams.range = 15;
    rgParams.seed = 3;
    rgInst = RandGen_create(&rgParams, NULL);
 
    for (i = 0; i < COUNT; i++) {
        System_printf("%d ", RandGen_next(rgInst)); 
    }
    System_printf("\n");
 
    return 0;
}
