/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef acme_filters__
#define acme_filters__


/*
 * ======== module acme.filters.Fir ========
 */

typedef struct acme_filters_Fir_Params acme_filters_Fir_Params;
typedef struct acme_filters_Fir_Object acme_filters_Fir_Object;
typedef struct acme_filters_Fir_Struct acme_filters_Fir_Struct;
typedef acme_filters_Fir_Object* acme_filters_Fir_Handle;
typedef struct acme_filters_Fir_Object__ acme_filters_Fir_Instance_State;


#endif /* acme_filters__ */ 
