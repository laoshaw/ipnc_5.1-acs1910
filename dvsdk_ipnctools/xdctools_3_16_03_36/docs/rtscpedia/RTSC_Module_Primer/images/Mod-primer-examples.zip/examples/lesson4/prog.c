/*
 *  ======== lesson4/prog.c ========
 */

#include <bravo/math/RandGen.h>
#include <xdc/runtime/System.h>
 
#include <xdc/cfg/global.h>
 
#define COUNT 10
 
Void printNums(RandGen_Handle rgInst, String label)
{
    Int i;

    System_printf("%s:\n\t", label);
    for (i = 0; i < COUNT; i++) {
        System_printf("%d ", RandGen_next(rgInst)); 
    }
    System_printf("\n\n");
}
 
Int main()
{
    RandGen_Handle rgInstHandle;
    RandGen_Struct rgInstStruct;
    RandGen_Params rgParams;
 
    RandGen_Params_init(&rgParams);
 
    rgParams.range = 15;
    rgParams.seed = 3;
    rgInstHandle = RandGen_create(&rgParams, NULL);
 
    rgParams.range = 25;
    rgParams.seed = 2;
    RandGen_construct(&rgInstStruct, &rgParams);
 
    printNums(rgInstHandle, "dynamically-created instance");
    printNums(RandGen_handle(&rgInstStruct), "dynamically-constructed instance");
    printNums(rgInstStatic, "statically-created instance");
 
    RandGen_delete(&rgInstHandle);
    RandGen_destruct(&rgInstStruct);
 
    return 0;
}
