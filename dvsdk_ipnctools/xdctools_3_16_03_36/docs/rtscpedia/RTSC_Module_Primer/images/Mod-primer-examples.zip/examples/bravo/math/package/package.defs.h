/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef bravo_math__
#define bravo_math__


/*
 * ======== module bravo.math.RandGen ========
 */

typedef struct bravo_math_RandGen_Params bravo_math_RandGen_Params;
typedef struct bravo_math_RandGen_Object bravo_math_RandGen_Object;
typedef struct bravo_math_RandGen_Struct bravo_math_RandGen_Struct;
typedef bravo_math_RandGen_Object* bravo_math_RandGen_Handle;
typedef struct bravo_math_RandGen_Object__ bravo_math_RandGen_Instance_State;


#endif /* bravo_math__ */ 
