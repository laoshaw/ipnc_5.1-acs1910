/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef acme_filters_Fir__INTERNAL__
#define acme_filters_Fir__INTERNAL__

#ifndef acme_filters_Fir__internalaccess
#define acme_filters_Fir__internalaccess
#endif

#include <acme/filters/Fir.h>

#undef xdc_FILE__
#ifndef xdc_FILE
#define xdc_FILE__ NULL
#else
#define xdc_FILE__ xdc_FILE
#endif

/* apply */
#undef acme_filters_Fir_apply
#define acme_filters_Fir_apply acme_filters_Fir_apply__F

/* Module_startup */
#undef acme_filters_Fir_Module_startup
#define acme_filters_Fir_Module_startup acme_filters_Fir_Module_startup__F

/* Instance_init */
#undef acme_filters_Fir_Instance_init
#define acme_filters_Fir_Instance_init acme_filters_Fir_Instance_init__F

/* Instance_finalize */
#undef acme_filters_Fir_Instance_finalize
#define acme_filters_Fir_Instance_finalize acme_filters_Fir_Instance_finalize__F

/* per-module runtime symbols */
#undef Module__MID
#define Module__MID acme_filters_Fir_Module__id__C
#undef Module__DGSINCL
#define Module__DGSINCL acme_filters_Fir_Module__diagsIncluded__C
#undef Module__DGSENAB
#define Module__DGSENAB acme_filters_Fir_Module__diagsEnabled__C
#undef Module__DGSMASK
#define Module__DGSMASK acme_filters_Fir_Module__diagsMask__C
#undef Module__LOGDEF
#define Module__LOGDEF acme_filters_Fir_Module__loggerDefined__C
#undef Module__LOGOBJ
#define Module__LOGOBJ acme_filters_Fir_Module__loggerObj__C
#undef Module__LOGFXN4
#define Module__LOGFXN4 acme_filters_Fir_Module__loggerFxn4__C
#undef Module__LOGFXN8
#define Module__LOGFXN8 acme_filters_Fir_Module__loggerFxn8__C
#undef Module__G_OBJ
#define Module__G_OBJ acme_filters_Fir_Module__gateObj__C
#undef Module__G_PRMS
#define Module__G_PRMS acme_filters_Fir_Module__gatePrms__C
#undef Module__GP_create
#define Module__GP_create acme_filters_Fir_Module_GateProxy_create
#undef Module__GP_delete
#define Module__GP_delete acme_filters_Fir_Module_GateProxy_delete
#undef Module__GP_enter
#define Module__GP_enter acme_filters_Fir_Module_GateProxy_enter
#undef Module__GP_leave
#define Module__GP_leave acme_filters_Fir_Module_GateProxy_leave
#undef Module__GP_query
#define Module__GP_query acme_filters_Fir_Module_GateProxy_query

/* Object__sizingError */
#line 1 "Error_inconsistent_object_size_in_acme.filters.Fir"
typedef char acme_filters_Fir_Object__sizingError[sizeof(acme_filters_Fir_Object) > sizeof(acme_filters_Fir_Struct) ? -1 : 1];


#endif /* acme_filters_Fir__INTERNAL____ */
