/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef acme_utils__
#define acme_utils__


/*
 * ======== module acme.utils.Bench ========
 */

typedef struct acme_utils_Bench_Module_State acme_utils_Bench_Module_State;


#endif /* acme_utils__ */ 
