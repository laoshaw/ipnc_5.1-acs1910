/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */
import java.util.*;
import org.mozilla.javascript.*;
import xdc.services.intern.xsr.*;
import xdc.services.spec.*;

public class bravo_math
{
    static final String VERS = "@(#) xdc-t35\n";

    static final Proto.Elm $$T_Bool = Proto.Elm.newBool();
    static final Proto.Elm $$T_Num = Proto.Elm.newNum();
    static final Proto.Elm $$T_Str = Proto.Elm.newStr();
    static final Proto.Elm $$T_Obj = Proto.Elm.newObj();

    static final Proto.Fxn $$T_Met = new Proto.Fxn(null, null, 0, -1, false);
    static final Proto.Map $$T_Map = new Proto.Map($$T_Obj);
    static final Proto.Arr $$T_Vec = new Proto.Arr($$T_Obj);

    static final XScriptO $$DEFAULT = Value.DEFAULT;
    static final Object $$UNDEF = Undefined.instance;

    static final Proto.Obj $$Package = (Proto.Obj)Global.get("$$Package");
    static final Proto.Obj $$Module = (Proto.Obj)Global.get("$$Module");
    static final Proto.Obj $$Instance = (Proto.Obj)Global.get("$$Instance");
    static final Proto.Obj $$Params = (Proto.Obj)Global.get("$$Params");

    static final Object $$objFldGet = Global.get("$$objFldGet");
    static final Object $$objFldSet = Global.get("$$objFldSet");
    static final Object $$proxyGet = Global.get("$$proxyGet");
    static final Object $$proxySet = Global.get("$$proxySet");
    static final Object $$delegGet = Global.get("$$delegGet");
    static final Object $$delegSet = Global.get("$$delegSet");

    Scriptable xdcO;
    Session ses;
    Value.Obj om;

    boolean isROV;
    boolean isCFG;

    Proto.Obj pkgP;
    Value.Obj pkgV;

    ArrayList<Object> imports = new ArrayList<Object>();
    ArrayList<Object> loggables = new ArrayList<Object>();
    ArrayList<Object> mcfgs = new ArrayList<Object>();
    ArrayList<Object> proxies = new ArrayList<Object>();
    ArrayList<Object> sizes = new ArrayList<Object>();
    ArrayList<Object> tdefs = new ArrayList<Object>();

    void $$IMPORTS()
    {
        Global.callFxn("loadPackage", xdcO, "xdc");
        Global.callFxn("loadPackage", xdcO, "xdc.corevers");
        Global.callFxn("loadPackage", xdcO, "xdc.runtime");
    }

    void $$OBJECTS()
    {
        pkgP = (Proto.Obj)om.bind("bravo.math.Package", new Proto.Obj());
        pkgV = (Value.Obj)om.bind("bravo.math", new Value.Obj("bravo.math", pkgP));
    }

    void RandGen$$OBJECTS()
    {
        Proto.Obj po, spo;
        Value.Obj vo;

        po = (Proto.Obj)om.bind("bravo.math.RandGen.Module", new Proto.Obj());
        vo = (Value.Obj)om.bind("bravo.math.RandGen", new Value.Obj("bravo.math.RandGen", po));
        pkgV.bind("RandGen", vo);
        // decls 
        spo = (Proto.Obj)om.bind("bravo.math.RandGen$$Instance_State", new Proto.Obj());
        om.bind("bravo.math.RandGen.Instance_State", new Proto.Str(spo, false));
        // insts 
        Object insP = om.bind("bravo.math.RandGen.Instance", new Proto.Obj());
        po = (Proto.Obj)om.bind("bravo.math.RandGen$$Object", new Proto.Obj());
        Object objP = om.bind("bravo.math.RandGen.Object", new Proto.Str(po, false));
        po = (Proto.Obj)om.bind("bravo.math.RandGen$$Params", new Proto.Obj());
        om.bind("bravo.math.RandGen.Params", new Proto.Str(po, false));
        om.bind("bravo.math.RandGen.Handle", insP);
        if (isROV) {
            om.bind("bravo.math.RandGen.Object", om.find("bravo.math.RandGen.Instance_State"));
        }//isROV
    }

    void RandGen$$CONSTS()
    {
        // module RandGen
        om.bind("bravo.math.RandGen.MAXVALUE", Global.eval("(1 << 15) - 1"));
    }

    void RandGen$$CREATES()
    {
        Proto.Fxn fxn;
        StringBuilder sb;

        if (isCFG) {
            sb = new StringBuilder();
            sb.append("bravo$math$RandGen$$__initObject = function( inst ) {\n");
                sb.append("if (!this.$used) {\n");
                    sb.append("throw new Error(\"Function bravo.math.RandGen.create() called before xdc.useModule('bravo.math.RandGen')\");\n");
                sb.append("}\n");
                sb.append("var name = xdc.module('xdc.runtime.Text').defineRopeCord(inst.instance.name);\n");
                sb.append("inst.$object.$$bind('__name', name);\n");
                sb.append("this.instance$static$init.$fxn.apply(inst, [inst.$object, inst, inst.$module]);\n");
                sb.append("inst.$seal();\n");
            sb.append("};\n");
            Global.eval(sb.toString());
            fxn = (Proto.Fxn)om.bind("bravo.math.RandGen$$create", new Proto.Fxn(om.find("bravo.math.RandGen.Module"), om.find("bravo.math.RandGen.Instance"), 1, 0, false));
                        fxn.addArg(0, "__params", (Proto)om.find("bravo.math.RandGen.Params"), Global.newObject());
            sb = new StringBuilder();
            sb.append("bravo$math$RandGen$$create = function( __params ) {\n");
                sb.append("var __mod = xdc.om['bravo.math.RandGen'];\n");
                sb.append("var __inst = xdc.om['bravo.math.RandGen.Instance'].$$make();\n");
                sb.append("__inst.$$bind('$package', xdc.om['bravo.math']);\n");
                sb.append("__inst.$$bind('$index', __mod.$instances.length);\n");
                sb.append("__inst.$$bind('$category', 'Instance');\n");
                sb.append("__inst.$$bind('$args', {});\n");
                sb.append("__inst.$$bind('$module', __mod);\n");
                sb.append("__mod.$instances.$add(__inst);\n");
                sb.append("__inst.$$bind('$object', new xdc.om['bravo.math.RandGen'].Instance_State);\n");
                sb.append("for (__p in __params) __inst[__p] = __params[__p];\n");
                sb.append("var save = xdc.om.$curpkg;\n");
                sb.append("xdc.om.$$bind('$curpkg', __mod.$package.$name);\n");
                sb.append("__mod.instance$meta$init.$fxn.apply(__inst, []);\n");
                sb.append("xdc.om.$$bind('$curpkg', save);\n");
                sb.append("__inst.$$bless();\n");
                sb.append("if (xdc.om.$$phase >= 5) xdc.om['bravo.math.RandGen'].__initObject(__inst);\n");
                sb.append("__inst.$$bind('$$phase', xdc.om.$$phase);\n");
                sb.append("return __inst;\n");
            sb.append("}\n");
            Global.eval(sb.toString());
        }//isCFG
        if (isCFG) {
            fxn = (Proto.Fxn)om.bind("bravo.math.RandGen$$construct", new Proto.Fxn(om.find("bravo.math.RandGen.Module"), null, 2, 0, false));
                        fxn.addArg(0, "__obj", (Proto)om.find("bravo.math.RandGen$$Object"), null);
                        fxn.addArg(1, "__params", (Proto)om.find("bravo.math.RandGen.Params"), Global.newObject());
            sb = new StringBuilder();
            sb.append("bravo$math$RandGen$$construct = function( __obj, __params ) {\n");
                sb.append("var __mod = xdc.om['bravo.math.RandGen'];\n");
                sb.append("var __inst = __obj;\n");
                sb.append("__inst.$$bind('$args', {});\n");
                sb.append("__inst.$$bind('$module', __mod);\n");
                sb.append("__mod.$objects.$add(__inst);\n");
                sb.append("__inst.$$bind('$object', xdc.om['bravo.math.RandGen'].Instance_State.$$make(__inst.$$parent, __inst.$name));\n");
                sb.append("for (__p in __params) __inst[__p] = __params[__p];\n");
                sb.append("__inst.$$bless();\n");
                sb.append("if (xdc.om.$$phase >= 5) xdc.om['bravo.math.RandGen'].__initObject(__inst);\n");
                sb.append("__inst.$$bind('$$phase', xdc.om.$$phase);\n");
                sb.append("return null;\n");
            sb.append("}\n");
            Global.eval(sb.toString());
        }//isCFG
    }

    void RandGen$$FUNCTIONS()
    {
        Proto.Fxn fxn;

    }

    void RandGen$$SIZES()
    {
        Proto.Str so;
        Object fxn;

        so = (Proto.Str)om.find("bravo.math.RandGen.Instance_State");
        sizes.clear();
        sizes.add(Global.newArray("range", "TInt16"));
        sizes.add(Global.newArray("next", "ULong"));
        so.bind("$$sizes", Global.newArray(sizes.toArray()));
        fxn = Global.eval("function() { return $$sizeof(xdc.om['bravo.math.RandGen.Instance_State']); }");
        so.bind("$sizeof", fxn);
        fxn = Global.eval("function() { return $$alignof(xdc.om['bravo.math.RandGen.Instance_State']); }");
        so.bind("$alignof", fxn);
        fxn = Global.eval("function(fld) { return $$offsetof(xdc.om['bravo.math.RandGen.Instance_State'], fld); }");
        so.bind("$offsetof", fxn);
    }

    void RandGen$$TYPES()
    {
        Scriptable cap;
        Proto.Obj po;
        Proto.Str ps;
        Proto.Typedef pt;
        Object fxn;

        cap = (Scriptable)Global.callFxn("loadCapsule", xdcO, "bravo/math/RandGen.xs");
        om.bind("bravo.math.RandGen$$capsule", cap);
        po = (Proto.Obj)om.find("bravo.math.RandGen.Module");
        po.init("bravo.math.RandGen.Module", om.find("xdc.runtime.IModule.Module"));
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("MAXVALUE", Proto.Elm.newCNum("(xdc_Int16)"), Global.eval("(1 << 15) - 1"), "rh");
        if (isCFG) {
        }//isCFG
        if (isCFG) {
                        po.addFxn("create", (Proto.Fxn)om.find("bravo.math.RandGen$$create"), Global.get("bravo$math$RandGen$$create"));
                        po.addFxn("construct", (Proto.Fxn)om.find("bravo.math.RandGen$$construct"), Global.get("bravo$math$RandGen$$construct"));
        }//isCFG
                fxn = Global.get(cap, "module$use");
                if (fxn != null) om.bind("bravo.math.RandGen$$module$use", true);
                if (fxn != null) po.addFxn("module$use", $$T_Met, fxn);
                fxn = Global.get(cap, "module$meta$init");
                if (fxn != null) om.bind("bravo.math.RandGen$$module$meta$init", true);
                if (fxn != null) po.addFxn("module$meta$init", $$T_Met, fxn);
                fxn = Global.get(cap, "instance$meta$init");
                if (fxn != null) om.bind("bravo.math.RandGen$$instance$meta$init", true);
                if (fxn != null) po.addFxn("instance$meta$init", $$T_Met, fxn);
                fxn = Global.get(cap, "module$static$init");
                if (fxn != null) om.bind("bravo.math.RandGen$$module$static$init", true);
                if (fxn != null) po.addFxn("module$static$init", $$T_Met, fxn);
                fxn = Global.get(cap, "module$validate");
                if (fxn != null) om.bind("bravo.math.RandGen$$module$validate", true);
                if (fxn != null) po.addFxn("module$validate", $$T_Met, fxn);
                fxn = Global.get(cap, "instance$static$init");
                if (fxn != null) om.bind("bravo.math.RandGen$$instance$static$init", true);
                if (fxn != null) po.addFxn("instance$static$init", $$T_Met, fxn);
        po = (Proto.Obj)om.find("bravo.math.RandGen.Instance");
        po.init("bravo.math.RandGen.Instance", $$Instance);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("MAXVALUE", Proto.Elm.newCNum("(xdc_Int16)"), Global.eval("(1 << 15) - 1"), "rh");
        if (isCFG) {
                        po.addFld("range", Proto.Elm.newCNum("(xdc_Int16)"), Global.eval("(1 << 15) - 1"), "w");
                        po.addFld("seed", Proto.Elm.newCNum("(xdc_UInt)"), 1L, "w");
                        po.addFld("instance", (Proto)om.find("xdc.runtime.IInstance.Params"), $$UNDEF, "w");
        }//isCFG
        po = (Proto.Obj)om.find("bravo.math.RandGen$$Params");
        po.init("bravo.math.RandGen.Params", $$Params);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("MAXVALUE", Proto.Elm.newCNum("(xdc_Int16)"), Global.eval("(1 << 15) - 1"), "rh");
        if (isCFG) {
                        po.addFld("range", Proto.Elm.newCNum("(xdc_Int16)"), Global.eval("(1 << 15) - 1"), "w");
                        po.addFld("seed", Proto.Elm.newCNum("(xdc_UInt)"), 1L, "w");
                        po.addFld("instance", (Proto)om.find("xdc.runtime.IInstance.Params"), $$UNDEF, "w");
        }//isCFG
        po = (Proto.Obj)om.find("bravo.math.RandGen$$Object");
        po.init("bravo.math.RandGen.Object", om.find("bravo.math.RandGen.Instance"));
        // struct RandGen.Instance_State
        po = (Proto.Obj)om.find("bravo.math.RandGen$$Instance_State");
        po.init("bravo.math.RandGen.Instance_State", null);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("range", Proto.Elm.newCNum("(xdc_Int16)"), $$UNDEF, "w");
                po.addFld("next", Proto.Elm.newCNum("(xdc_ULong)"), $$UNDEF, "w");
    }

    void RandGen$$ROV()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.find("bravo.math.RandGen");
        vo.bind("Instance_State$fetchDesc", Global.newObject("type", "bravo.math.RandGen.Instance_State", "isScalar", false));
        po = (Proto.Obj)om.find("bravo.math.RandGen$$Instance_State");
    }

    void $$SINGLETONS()
    {
        pkgP.init("bravo.math.Package", (Proto.Obj)om.find("xdc.IPackage.Module"));
        pkgP.bind("$capsule", $$UNDEF);
        pkgV.init2(pkgP, "bravo.math", Value.DEFAULT, false);
        pkgV.bind("$name", "bravo.math");
        pkgV.bind("$category", "Package");
        pkgV.bind("$$qn", "bravo.math.");
        pkgV.bind("$vers", Global.newArray());
        Value.Map atmap = (Value.Map)pkgV.getv("$attr");
        atmap.seal("length");
        imports.clear();
        pkgV.bind("$imports", imports);
        StringBuilder sb = new StringBuilder();
        sb.append("var pkg = xdc.om['bravo.math'];\n");
        sb.append("if (pkg.$vers.length >= 3) {\n");
            sb.append("pkg.$vers.push(Packages.xdc.services.global.Vers.getDate(xdc.csd() + '/..'));\n");
        sb.append("}\n");
        sb.append("pkg.build.libraries = [\n");
            sb.append("'lib/bravo.math.a64P',\n");
            sb.append("'lib/bravo.math.a86GW',\n");
        sb.append("];\n");
        sb.append("pkg.build.libDesc = [\n");
            sb.append("['lib/bravo.math.a64P', {target: 'ti.targets.C64P'}],\n");
            sb.append("['lib/bravo.math.a86GW', {target: 'gnu.targets.Mingw'}],\n");
        sb.append("];\n");
        sb.append("if('suffix' in xdc.om['xdc.IPackage$$LibDesc']) {\n");
            sb.append("pkg.build.libDesc['lib/bravo.math.a64P'].suffix = '64P';\n");
            sb.append("pkg.build.libDesc['lib/bravo.math.a86GW'].suffix = '86GW';\n");
        sb.append("}\n");
        Global.eval(sb.toString());
    }

    void RandGen$$SINGLETONS()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.find("bravo.math.RandGen");
        po = (Proto.Obj)om.find("bravo.math.RandGen.Module");
        vo.init2(po, "bravo.math.RandGen", $$DEFAULT, false);
        vo.bind("Module", po);
        vo.bind("$category", "Module");
        vo.bind("$capsule", om.find("bravo.math.RandGen$$capsule"));
        vo.bind("Instance", om.find("bravo.math.RandGen.Instance"));
        vo.bind("Params", om.find("bravo.math.RandGen.Params"));
        vo.bind("PARAMS", ((Proto.Str)om.find("bravo.math.RandGen.Params")).newInstance());
        vo.bind("Handle", om.find("bravo.math.RandGen.Handle"));
        vo.bind("$package", om.find("bravo.math"));
        tdefs.clear();
        proxies.clear();
        mcfgs.clear();
        mcfgs.add("Module__diagsEnabled");
        mcfgs.add("Module__diagsIncluded");
        mcfgs.add("Module__diagsMask");
        mcfgs.add("Module__gateObj");
        mcfgs.add("Module__gatePrms");
        mcfgs.add("Module__id");
        mcfgs.add("Module__loggerDefined");
        mcfgs.add("Module__loggerObj");
        mcfgs.add("Module__loggerFxn4");
        mcfgs.add("Module__loggerFxn8");
        mcfgs.add("Module__startupDoneFxn");
        mcfgs.add("Object__count");
        mcfgs.add("Object__heap");
        mcfgs.add("Object__sizeof");
        mcfgs.add("Object__table");
        vo.bind("Instance_State", om.find("bravo.math.RandGen.Instance_State"));
        tdefs.add(om.find("bravo.math.RandGen.Instance_State"));
        vo.bind("$$tdefs", Global.newArray(tdefs.toArray()));
        vo.bind("$$proxies", Global.newArray(proxies.toArray()));
        vo.bind("$$mcfgs", Global.newArray(mcfgs.toArray()));
        ((Value.Arr)pkgV.getv("$modules")).add(vo);
        ((Value.Arr)om.find("$modules")).add(vo);
        vo.bind("$$instflag", 1);
        vo.bind("$$iobjflag", 1);
        vo.bind("$$sizeflag", 1);
        vo.bind("$$dlgflag", 0);
        vo.bind("$$iflag", 0);
        vo.bind("$$romcfgs", "|");
        if (isCFG) {
            Proto.Str ps = (Proto.Str)vo.find("Module_State");
            if (ps != null) vo.bind("$object", ps.newInstance());
            vo.bind("$$meta_iobj", om.has("bravo.math.RandGen$$instance$static$init", null) ? 1 : 0);
            vo.bind("__initObject", Global.get("bravo$math$RandGen$$__initObject"));
        }//isCFG
        vo.bind("$$fxntab", Global.newArray("bravo_math_RandGen_Handle__label__E", "bravo_math_RandGen_Module__startupDone__E", "bravo_math_RandGen_Object__create__E", "bravo_math_RandGen_Object__delete__E", "bravo_math_RandGen_Object__destruct__E", "bravo_math_RandGen_Object__get__E", "bravo_math_RandGen_Object__first__E", "bravo_math_RandGen_Object__next__E", "bravo_math_RandGen_Params__init__E", "bravo_math_RandGen_Proxy__abstract__E", "bravo_math_RandGen_Proxy__delegate__E", "bravo_math_RandGen_next__E", "bravo_math_RandGen_nextn__E"));
        vo.bind("$$logEvtCfgs", Global.newArray());
        vo.bind("$$errorDescCfgs", Global.newArray());
        vo.bind("$$assertDescCfgs", Global.newArray());
        Value.Map atmap = (Value.Map)vo.getv("$attr");
        atmap.seal("length");
        vo.bind("Object", om.find("bravo.math.RandGen.Object"));
        vo.bind("MODULE_STARTUP$", 0);
        vo.bind("PROXY$", 0);
        loggables.clear();
        loggables.add(Global.newObject("name", "next", "entry", "%p", "exit", "%d"));
        loggables.add(Global.newObject("name", "nextn", "entry", "%p, %p, %d", "exit", ""));
        vo.bind("$$loggables", loggables.toArray());
        pkgV.bind("RandGen", vo);
        ((Value.Arr)pkgV.getv("$unitNames")).add("RandGen");
    }

    void $$INITIALIZATION()
    {
        Value.Obj vo;

        if (isCFG) {
            Object srcP = ((XScriptO)om.find("xdc.runtime.IInstance")).find("PARAMS");
            Scriptable dstP;

            dstP = (Scriptable)((XScriptO)om.find("bravo.math.RandGen")).find("PARAMS");
            Global.put(dstP, "instance", srcP);
        }//isCFG
        Global.callFxn("module$meta$init", (Scriptable)om.find("bravo.math.RandGen"));
        Global.callFxn("init", pkgV);
        ((Value.Obj)om.getv("bravo.math.RandGen")).bless();
        ((Value.Arr)om.find("$packages")).add(pkgV);
    }

    public void exec( Scriptable xdcO, Session ses )
    {
        this.xdcO = xdcO;
        this.ses = ses;
        om = (Value.Obj)xdcO.get("om", null);

        Object o = om.geto("$name");
        String s = o instanceof String ? (String)o : null;
        isCFG = s != null && s.equals("cfg");
        isROV = s != null && s.equals("rov");

        $$IMPORTS();
        $$OBJECTS();
        RandGen$$OBJECTS();
        RandGen$$CONSTS();
        RandGen$$CREATES();
        RandGen$$FUNCTIONS();
        RandGen$$SIZES();
        RandGen$$TYPES();
        if (isROV) {
            RandGen$$ROV();
        }//isROV
        $$SINGLETONS();
        RandGen$$SINGLETONS();
        $$INITIALIZATION();
    }
}
