/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

#ifndef bravo_math_RandGen__INTERNAL__
#define bravo_math_RandGen__INTERNAL__

#ifndef bravo_math_RandGen__internalaccess
#define bravo_math_RandGen__internalaccess
#endif

#include <bravo/math/RandGen.h>

#undef xdc_FILE__
#ifndef xdc_FILE
#define xdc_FILE__ NULL
#else
#define xdc_FILE__ xdc_FILE
#endif

/* next */
#undef bravo_math_RandGen_next
#define bravo_math_RandGen_next bravo_math_RandGen_next__F

/* nextn */
#undef bravo_math_RandGen_nextn
#define bravo_math_RandGen_nextn bravo_math_RandGen_nextn__F

/* Module_startup */
#undef bravo_math_RandGen_Module_startup
#define bravo_math_RandGen_Module_startup bravo_math_RandGen_Module_startup__F

/* Instance_init */
#undef bravo_math_RandGen_Instance_init
#define bravo_math_RandGen_Instance_init bravo_math_RandGen_Instance_init__F

/* Instance_finalize */
#undef bravo_math_RandGen_Instance_finalize
#define bravo_math_RandGen_Instance_finalize bravo_math_RandGen_Instance_finalize__F

/* per-module runtime symbols */
#undef Module__MID
#define Module__MID bravo_math_RandGen_Module__id__C
#undef Module__DGSINCL
#define Module__DGSINCL bravo_math_RandGen_Module__diagsIncluded__C
#undef Module__DGSENAB
#define Module__DGSENAB bravo_math_RandGen_Module__diagsEnabled__C
#undef Module__DGSMASK
#define Module__DGSMASK bravo_math_RandGen_Module__diagsMask__C
#undef Module__LOGDEF
#define Module__LOGDEF bravo_math_RandGen_Module__loggerDefined__C
#undef Module__LOGOBJ
#define Module__LOGOBJ bravo_math_RandGen_Module__loggerObj__C
#undef Module__LOGFXN4
#define Module__LOGFXN4 bravo_math_RandGen_Module__loggerFxn4__C
#undef Module__LOGFXN8
#define Module__LOGFXN8 bravo_math_RandGen_Module__loggerFxn8__C
#undef Module__G_OBJ
#define Module__G_OBJ bravo_math_RandGen_Module__gateObj__C
#undef Module__G_PRMS
#define Module__G_PRMS bravo_math_RandGen_Module__gatePrms__C
#undef Module__GP_create
#define Module__GP_create bravo_math_RandGen_Module_GateProxy_create
#undef Module__GP_delete
#define Module__GP_delete bravo_math_RandGen_Module_GateProxy_delete
#undef Module__GP_enter
#define Module__GP_enter bravo_math_RandGen_Module_GateProxy_enter
#undef Module__GP_leave
#define Module__GP_leave bravo_math_RandGen_Module_GateProxy_leave
#undef Module__GP_query
#define Module__GP_query bravo_math_RandGen_Module_GateProxy_query

/* Object__sizingError */
#line 1 "Error_inconsistent_object_size_in_bravo.math.RandGen"
typedef char bravo_math_RandGen_Object__sizingError[sizeof(bravo_math_RandGen_Object) > sizeof(bravo_math_RandGen_Struct) ? -1 : 1];


#endif /* bravo_math_RandGen__INTERNAL____ */
