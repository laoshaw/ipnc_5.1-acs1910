/*
 *  ======== lesson6/prog.c ========
 */

#include <lesson6/Talker.h>
 
Int main()
{
    Talker_print();
    return 0;
}
