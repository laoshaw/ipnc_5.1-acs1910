/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

/*
 * ======== GENERATED SECTIONS ========
 *     
 *     PROLOGUE
 *     INCLUDES
 *     
 *     CREATE ARGS
 *     INTERNAL DEFINITIONS
 *     MODULE-WIDE CONFIGS
 *     PER-INSTANCE TYPES
 *     FUNCTION DECLARATIONS
 *     FUNCTION SELECTORS
 *     SYSTEM FUNCTIONS
 *     
 *     EPILOGUE
 *     STATE STRUCTURES
 *     PREFIX ALIASES
 */


/*
 * ======== PROLOGUE ========
 */

#ifndef acme_filters_Fir__include
#define acme_filters_Fir__include

#ifndef __nested__
#define __nested__
#define acme_filters_Fir__top__
#endif

#ifdef __cplusplus
#define __extern extern "C"
#else
#define __extern extern
#endif

#define acme_filters_Fir___VERS 150


/*
 * ======== INCLUDES ========
 */

#include <xdc/std.h>

#include <xdc/runtime/xdc.h>
#include <xdc/runtime/Types.h>
#include <xdc/runtime/IInstance.h>
#include <acme/filters/package/package.defs.h>

#include <xdc/runtime/IModule.h>


/*
 * ======== AUXILIARY DEFINITIONS ========
 */


/*
 * ======== CREATE ARGS ========
 */

/* Args__create */
typedef xdc_Int16 __T1_acme_filters_Fir_Args__create__coeffs;
typedef xdc_Int16 *__ARRAY1_acme_filters_Fir_Args__create__coeffs;
typedef __ARRAY1_acme_filters_Fir_Args__create__coeffs __TA_acme_filters_Fir_Args__create__coeffs;
typedef struct acme_filters_Fir_Args__create {
    __TA_acme_filters_Fir_Args__create__coeffs coeffs;
    xdc_Int coeffsLen;
} acme_filters_Fir_Args__create;


/*
 * ======== INTERNAL DEFINITIONS ========
 */

/* Instance_State */
typedef xdc_Int16 __T1_acme_filters_Fir_Instance_State__coeffs;
typedef xdc_Int16 *__ARRAY1_acme_filters_Fir_Instance_State__coeffs;
typedef __ARRAY1_acme_filters_Fir_Instance_State__coeffs __TA_acme_filters_Fir_Instance_State__coeffs;
typedef xdc_Int16 __T1_acme_filters_Fir_Instance_State__history;
typedef xdc_Int16 *__ARRAY1_acme_filters_Fir_Instance_State__history;
typedef __ARRAY1_acme_filters_Fir_Instance_State__history __TA_acme_filters_Fir_Instance_State__history;


/*
 * ======== MODULE-WIDE CONFIGS ========
 */

/* Module__diagsEnabled */
typedef xdc_Bits32 CT__acme_filters_Fir_Module__diagsEnabled;
__extern __FAR__ const CT__acme_filters_Fir_Module__diagsEnabled acme_filters_Fir_Module__diagsEnabled__C;

/* Module__diagsIncluded */
typedef xdc_Bits32 CT__acme_filters_Fir_Module__diagsIncluded;
__extern __FAR__ const CT__acme_filters_Fir_Module__diagsIncluded acme_filters_Fir_Module__diagsIncluded__C;

/* Module__diagsMask */
typedef xdc_Bits16* CT__acme_filters_Fir_Module__diagsMask;
__extern __FAR__ const CT__acme_filters_Fir_Module__diagsMask acme_filters_Fir_Module__diagsMask__C;

/* Module__gateObj */
typedef xdc_Ptr CT__acme_filters_Fir_Module__gateObj;
__extern __FAR__ const CT__acme_filters_Fir_Module__gateObj acme_filters_Fir_Module__gateObj__C;

/* Module__gatePrms */
typedef xdc_Ptr CT__acme_filters_Fir_Module__gatePrms;
__extern __FAR__ const CT__acme_filters_Fir_Module__gatePrms acme_filters_Fir_Module__gatePrms__C;

/* Module__id */
typedef xdc_runtime_Types_ModuleId CT__acme_filters_Fir_Module__id;
__extern __FAR__ const CT__acme_filters_Fir_Module__id acme_filters_Fir_Module__id__C;

/* Module__loggerDefined */
typedef xdc_Bool CT__acme_filters_Fir_Module__loggerDefined;
__extern __FAR__ const CT__acme_filters_Fir_Module__loggerDefined acme_filters_Fir_Module__loggerDefined__C;

/* Module__loggerObj */
typedef xdc_Ptr CT__acme_filters_Fir_Module__loggerObj;
__extern __FAR__ const CT__acme_filters_Fir_Module__loggerObj acme_filters_Fir_Module__loggerObj__C;

/* Module__loggerFxn4 */
typedef xdc_runtime_Types_LoggerFxn4 CT__acme_filters_Fir_Module__loggerFxn4;
__extern __FAR__ const CT__acme_filters_Fir_Module__loggerFxn4 acme_filters_Fir_Module__loggerFxn4__C;

/* Module__loggerFxn8 */
typedef xdc_runtime_Types_LoggerFxn8 CT__acme_filters_Fir_Module__loggerFxn8;
__extern __FAR__ const CT__acme_filters_Fir_Module__loggerFxn8 acme_filters_Fir_Module__loggerFxn8__C;

/* Module__startupDoneFxn */
typedef xdc_Bool (*CT__acme_filters_Fir_Module__startupDoneFxn)(void);
__extern __FAR__ const CT__acme_filters_Fir_Module__startupDoneFxn acme_filters_Fir_Module__startupDoneFxn__C;

/* Object__count */
typedef xdc_Int CT__acme_filters_Fir_Object__count;
__extern __FAR__ const CT__acme_filters_Fir_Object__count acme_filters_Fir_Object__count__C;

/* Object__heap */
typedef xdc_runtime_IHeap_Handle CT__acme_filters_Fir_Object__heap;
__extern __FAR__ const CT__acme_filters_Fir_Object__heap acme_filters_Fir_Object__heap__C;

/* Object__sizeof */
typedef xdc_SizeT CT__acme_filters_Fir_Object__sizeof;
__extern __FAR__ const CT__acme_filters_Fir_Object__sizeof acme_filters_Fir_Object__sizeof__C;

/* Object__table */
typedef xdc_Ptr CT__acme_filters_Fir_Object__table;
__extern __FAR__ const CT__acme_filters_Fir_Object__table acme_filters_Fir_Object__table__C;


/*
 * ======== PER-INSTANCE TYPES ========
 */

/* Params */
struct acme_filters_Fir_Params {
    size_t __size;
    const void* __self;
    void* __fxns;
    xdc_runtime_IInstance_Params* instance;
    xdc_Int frameLen;
    xdc_runtime_IInstance_Params __iprms;
};

/* Struct */
struct acme_filters_Fir_Struct {
    __TA_acme_filters_Fir_Instance_State__coeffs __f0;
    xdc_Int __f1;
    xdc_Int __f2;
    __TA_acme_filters_Fir_Instance_State__history __f3;
    xdc_runtime_Types_CordAddr __name;
};


/*
 * ======== FUNCTION DECLARATIONS ========
 */

/* Module_startup */
#define acme_filters_Fir_Module_startup( state ) -1

/* Instance_init__F */
xdc__CODESECT(acme_filters_Fir_Instance_init__F, "acme_filters_Fir_Instance_init")
__extern int acme_filters_Fir_Instance_init__F( acme_filters_Fir_Object*, xdc_Int16 coeffs[], xdc_Int coeffsLen, const acme_filters_Fir_Params*, xdc_runtime_Error_Block* );

/* Instance_finalize__F */
xdc__CODESECT(acme_filters_Fir_Instance_finalize__F, "acme_filters_Fir_Instance_finalize")
__extern void acme_filters_Fir_Instance_finalize__F( acme_filters_Fir_Object* , int );

/* Instance_init__R */
xdc__CODESECT(acme_filters_Fir_Instance_init__R, "acme_filters_Fir_Instance_init")
__extern int acme_filters_Fir_Instance_init__R( acme_filters_Fir_Object*, xdc_Int16 coeffs[], xdc_Int coeffsLen, const acme_filters_Fir_Params*, xdc_runtime_Error_Block* );

/* Instance_finalize__R */
xdc__CODESECT(acme_filters_Fir_Instance_finalize__R, "acme_filters_Fir_Instance_finalize")
__extern void acme_filters_Fir_Instance_finalize__R( acme_filters_Fir_Object* , int );

/* Handle__label__S */
xdc__CODESECT(acme_filters_Fir_Handle__label__S, "acme_filters_Fir_Handle__label")
__extern xdc_runtime_Types_Label* acme_filters_Fir_Handle__label__S( xdc_Ptr obj, xdc_runtime_Types_Label* lab );

/* Module__startupDone__S */
xdc__CODESECT(acme_filters_Fir_Module__startupDone__S, "acme_filters_Fir_Module__startupDone")
__extern xdc_Bool acme_filters_Fir_Module__startupDone__S( void );

/* Object__create__S */
xdc__CODESECT(acme_filters_Fir_Object__create__S, "acme_filters_Fir_Object__create")
__extern xdc_Ptr acme_filters_Fir_Object__create__S( xdc_Ptr __oa, xdc_SizeT __osz, xdc_Ptr __aa, const xdc_UChar* __pa, xdc_SizeT __psz, xdc_runtime_Error_Block* __eb );

/* Object__delete__S */
xdc__CODESECT(acme_filters_Fir_Object__delete__S, "acme_filters_Fir_Object__delete")
__extern xdc_Void acme_filters_Fir_Object__delete__S( xdc_Ptr instp );

/* Object__destruct__S */
xdc__CODESECT(acme_filters_Fir_Object__destruct__S, "acme_filters_Fir_Object__destruct")
__extern xdc_Void acme_filters_Fir_Object__destruct__S( xdc_Ptr objp );

/* Object__get__S */
xdc__CODESECT(acme_filters_Fir_Object__get__S, "acme_filters_Fir_Object__get")
__extern xdc_Ptr acme_filters_Fir_Object__get__S( xdc_Ptr oarr, xdc_Int i );

/* Object__first__S */
xdc__CODESECT(acme_filters_Fir_Object__first__S, "acme_filters_Fir_Object__first")
__extern xdc_Ptr acme_filters_Fir_Object__first__S( void );

/* Object__next__S */
xdc__CODESECT(acme_filters_Fir_Object__next__S, "acme_filters_Fir_Object__next")
__extern xdc_Ptr acme_filters_Fir_Object__next__S( xdc_Ptr obj );

/* Params__init__S */
xdc__CODESECT(acme_filters_Fir_Params__init__S, "acme_filters_Fir_Params__init")
__extern xdc_Void acme_filters_Fir_Params__init__S( xdc_Ptr dst, xdc_Ptr src, xdc_SizeT psz, xdc_SizeT isz );

/* Proxy__abstract__S */
xdc__CODESECT(acme_filters_Fir_Proxy__abstract__S, "acme_filters_Fir_Proxy__abstract")
__extern xdc_Bool acme_filters_Fir_Proxy__abstract__S( void );

/* Proxy__delegate__S */
xdc__CODESECT(acme_filters_Fir_Proxy__delegate__S, "acme_filters_Fir_Proxy__delegate")
__extern xdc_Ptr acme_filters_Fir_Proxy__delegate__S( void );

/* apply__E */
#define acme_filters_Fir_apply acme_filters_Fir_apply__E
xdc__CODESECT(acme_filters_Fir_apply__E, "acme_filters_Fir_apply")
__extern xdc_Void acme_filters_Fir_apply__E( acme_filters_Fir_Handle __inst, xdc_Int16 inFrame[], xdc_Int16 outFrame[] );
xdc__CODESECT(acme_filters_Fir_apply__F, "acme_filters_Fir_apply")
__extern xdc_Void acme_filters_Fir_apply__F( acme_filters_Fir_Object* __inst, xdc_Int16 inFrame[], xdc_Int16 outFrame[] );
__extern xdc_Void acme_filters_Fir_apply__R( acme_filters_Fir_Handle __inst, xdc_Int16 inFrame[], xdc_Int16 outFrame[] );


/*
 * ======== FUNCTION SELECTORS ========
 */

/* apply_{FxnT,fxnP} */
typedef xdc_Void (*acme_filters_Fir_apply_FxnT)(void*, xdc_Int16[], xdc_Int16[]);
static inline acme_filters_Fir_apply_FxnT acme_filters_Fir_apply_fxnP( void )
{
    return (acme_filters_Fir_apply_FxnT)acme_filters_Fir_apply; 
}


/*
 * ======== SYSTEM FUNCTIONS ========
 */

/* Module_startupDone */
#define acme_filters_Fir_Module_startupDone() acme_filters_Fir_Module__startupDone__S()

/* Object_heap */
#define acme_filters_Fir_Object_heap() acme_filters_Fir_Object__heap__C

/* Module_heap */
#define acme_filters_Fir_Module_heap() acme_filters_Fir_Object__heap__C

/* Module_id */
static inline CT__acme_filters_Fir_Module__id acme_filters_Fir_Module_id( void ) 
{
    return acme_filters_Fir_Module__id__C;
}

/* Module_hasMask */
static inline xdc_Bool acme_filters_Fir_Module_hasMask( void ) 
{
    return acme_filters_Fir_Module__diagsMask__C != NULL;
}

/* Module_getMask */
static inline xdc_Bits16 acme_filters_Fir_Module_getMask( void ) 
{
    return acme_filters_Fir_Module__diagsMask__C != NULL ? *acme_filters_Fir_Module__diagsMask__C : 0;
}

/* Module_setMask */
static inline xdc_Void acme_filters_Fir_Module_setMask( xdc_Bits16 mask ) 
{
    if (acme_filters_Fir_Module__diagsMask__C != NULL) *acme_filters_Fir_Module__diagsMask__C = mask;
}

/* Params_init */
static inline void acme_filters_Fir_Params_init( acme_filters_Fir_Params* prms ) 
{
    if (prms) {
        acme_filters_Fir_Params__init__S(prms, 0, sizeof(acme_filters_Fir_Params), sizeof(xdc_runtime_IInstance_Params));
    }
}

/* Params_copy */
static inline void acme_filters_Fir_Params_copy( acme_filters_Fir_Params* dst, const acme_filters_Fir_Params* src ) 
{
    if (dst) {
        acme_filters_Fir_Params__init__S(dst, (xdc_Ptr)src, sizeof(acme_filters_Fir_Params), sizeof(xdc_runtime_IInstance_Params));
    }
}

/* Object_count */
#define acme_filters_Fir_Object_count() acme_filters_Fir_Object__count__C

/* Object_sizeof */
#define acme_filters_Fir_Object_sizeof() acme_filters_Fir_Object__sizeof__C

/* Object_get */
static inline acme_filters_Fir_Handle acme_filters_Fir_Object_get( acme_filters_Fir_Instance_State* oarr, int i ) 
{
    return (acme_filters_Fir_Handle)acme_filters_Fir_Object__get__S(oarr, i);
}

/* Object_first */
static inline acme_filters_Fir_Handle acme_filters_Fir_Object_first( void )
{
    return (acme_filters_Fir_Handle)acme_filters_Fir_Object__first__S();
}

/* Object_next */
static inline acme_filters_Fir_Handle acme_filters_Fir_Object_next( acme_filters_Fir_Object* obj )
{
    return (acme_filters_Fir_Handle)acme_filters_Fir_Object__next__S(obj);
}

/* Handle_label */
static inline xdc_runtime_Types_Label* acme_filters_Fir_Handle_label( acme_filters_Fir_Handle inst, xdc_runtime_Types_Label* lab )
{
    return acme_filters_Fir_Handle__label__S(inst, lab);
}

/* Handle_name */
static inline String acme_filters_Fir_Handle_name( acme_filters_Fir_Handle inst )
{
    xdc_runtime_Types_Label lab;
    return acme_filters_Fir_Handle__label__S(inst, &lab)->iname;
}

/* create */
static inline acme_filters_Fir_Handle acme_filters_Fir_create( xdc_Int16 coeffs[], xdc_Int coeffsLen, const acme_filters_Fir_Params* __prms, xdc_runtime_Error_Block* __eb )
{
    acme_filters_Fir_Args__create __args;
    __args.coeffs = coeffs;
    __args.coeffsLen = coeffsLen;
    return (acme_filters_Fir_Handle)acme_filters_Fir_Object__create__S(0, 0, &__args, (const xdc_UChar*)__prms, sizeof(acme_filters_Fir_Params), __eb);
}

/* construct */
static inline void acme_filters_Fir_construct( acme_filters_Fir_Struct* __obj, xdc_Int16 coeffs[], xdc_Int coeffsLen, const acme_filters_Fir_Params* __prms, xdc_runtime_Error_Block* __eb )
{
    acme_filters_Fir_Args__create __args;
    __args.coeffs = coeffs;
    __args.coeffsLen = coeffsLen;
    acme_filters_Fir_Object__create__S(__obj, sizeof (acme_filters_Fir_Struct), &__args, (const xdc_UChar*)__prms, sizeof(acme_filters_Fir_Params), __eb);
}

/* delete */
static inline void acme_filters_Fir_delete( acme_filters_Fir_Handle* instp )
{
    acme_filters_Fir_Object__delete__S(instp);
}

/* destruct */
static inline void acme_filters_Fir_destruct( acme_filters_Fir_Struct* obj )
{
    acme_filters_Fir_Object__destruct__S(obj);
}

/* handle */
static inline acme_filters_Fir_Handle acme_filters_Fir_handle( acme_filters_Fir_Struct* str )
{
    return (acme_filters_Fir_Handle)str;
}

/* struct */
static inline acme_filters_Fir_Struct* acme_filters_Fir_struct( acme_filters_Fir_Handle inst )
{
    return (acme_filters_Fir_Struct*)inst;
}


/*
 * ======== EPILOGUE ========
 */

#ifdef acme_filters_Fir__top__
#undef __nested__
#endif

#endif /* acme_filters_Fir__include */


/*
 * ======== STATE STRUCTURES ========
 */

#if defined(__config__) || (!defined(__nested__) && defined(acme_filters_Fir__internalaccess))

#ifndef acme_filters_Fir__include_state
#define acme_filters_Fir__include_state

/* Object */
struct acme_filters_Fir_Object {
    __TA_acme_filters_Fir_Instance_State__coeffs coeffs;
    xdc_Int coeffsLen;
    xdc_Int frameLen;
    __TA_acme_filters_Fir_Instance_State__history history;
};

#endif /* acme_filters_Fir__include_state */

#endif


/*
 * ======== PREFIX ALIASES ========
 */

#if !defined(__nested__) && !defined(acme_filters_Fir__nolocalnames)

/* module prefix */
#define Fir_Instance acme_filters_Fir_Instance
#define Fir_Handle acme_filters_Fir_Handle
#define Fir_Module acme_filters_Fir_Module
#define Fir_Object acme_filters_Fir_Object
#define Fir_Struct acme_filters_Fir_Struct
#define Fir_Instance_State acme_filters_Fir_Instance_State
#define Fir_Params acme_filters_Fir_Params
#define Fir_apply acme_filters_Fir_apply
#define Fir_apply_fxnP acme_filters_Fir_apply_fxnP
#define Fir_apply_FxnT acme_filters_Fir_apply_FxnT
#define Fir_Module_name acme_filters_Fir_Module_name
#define Fir_Module_id acme_filters_Fir_Module_id
#define Fir_Module_startup acme_filters_Fir_Module_startup
#define Fir_Module_startupDone acme_filters_Fir_Module_startupDone
#define Fir_Module_hasMask acme_filters_Fir_Module_hasMask
#define Fir_Module_getMask acme_filters_Fir_Module_getMask
#define Fir_Module_setMask acme_filters_Fir_Module_setMask
#define Fir_Object_heap acme_filters_Fir_Object_heap
#define Fir_Module_heap acme_filters_Fir_Module_heap
#define Fir_construct acme_filters_Fir_construct
#define Fir_create acme_filters_Fir_create
#define Fir_handle acme_filters_Fir_handle
#define Fir_struct acme_filters_Fir_struct
#define Fir_Handle_label acme_filters_Fir_Handle_label
#define Fir_Handle_name acme_filters_Fir_Handle_name
#define Fir_Instance_init acme_filters_Fir_Instance_init
#define Fir_Object_count acme_filters_Fir_Object_count
#define Fir_Object_get acme_filters_Fir_Object_get
#define Fir_Object_first acme_filters_Fir_Object_first
#define Fir_Object_next acme_filters_Fir_Object_next
#define Fir_Object_sizeof acme_filters_Fir_Object_sizeof
#define Fir_Params_copy acme_filters_Fir_Params_copy
#define Fir_Params_init acme_filters_Fir_Params_init
#define Fir_Instance_finalize acme_filters_Fir_Instance_finalize
#define Fir_delete acme_filters_Fir_delete
#define Fir_destruct acme_filters_Fir_destruct

#endif
