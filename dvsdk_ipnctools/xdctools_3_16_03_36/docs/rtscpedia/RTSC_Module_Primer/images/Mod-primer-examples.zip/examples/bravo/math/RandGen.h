/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */

/*
 * ======== GENERATED SECTIONS ========
 *     
 *     PROLOGUE
 *     INCLUDES
 *     
 *     INTERNAL DEFINITIONS
 *     MODULE-WIDE CONFIGS
 *     PER-INSTANCE TYPES
 *     FUNCTION DECLARATIONS
 *     FUNCTION SELECTORS
 *     SYSTEM FUNCTIONS
 *     
 *     EPILOGUE
 *     STATE STRUCTURES
 *     PREFIX ALIASES
 */


/*
 * ======== PROLOGUE ========
 */

#ifndef bravo_math_RandGen__include
#define bravo_math_RandGen__include

#ifndef __nested__
#define __nested__
#define bravo_math_RandGen__top__
#endif

#ifdef __cplusplus
#define __extern extern "C"
#else
#define __extern extern
#endif

#define bravo_math_RandGen___VERS 150


/*
 * ======== INCLUDES ========
 */

#include <xdc/std.h>

#include <xdc/runtime/xdc.h>
#include <xdc/runtime/Types.h>
#include <xdc/runtime/IInstance.h>
#include <bravo/math/package/package.defs.h>

#include <xdc/runtime/IModule.h>


/*
 * ======== AUXILIARY DEFINITIONS ========
 */

/* MAXVALUE */
#define bravo_math_RandGen_MAXVALUE ((1U << 15) - 1)


/*
 * ======== INTERNAL DEFINITIONS ========
 */


/*
 * ======== MODULE-WIDE CONFIGS ========
 */

/* Module__diagsEnabled */
typedef xdc_Bits32 CT__bravo_math_RandGen_Module__diagsEnabled;
__extern __FAR__ const CT__bravo_math_RandGen_Module__diagsEnabled bravo_math_RandGen_Module__diagsEnabled__C;

/* Module__diagsIncluded */
typedef xdc_Bits32 CT__bravo_math_RandGen_Module__diagsIncluded;
__extern __FAR__ const CT__bravo_math_RandGen_Module__diagsIncluded bravo_math_RandGen_Module__diagsIncluded__C;

/* Module__diagsMask */
typedef xdc_Bits16* CT__bravo_math_RandGen_Module__diagsMask;
__extern __FAR__ const CT__bravo_math_RandGen_Module__diagsMask bravo_math_RandGen_Module__diagsMask__C;

/* Module__gateObj */
typedef xdc_Ptr CT__bravo_math_RandGen_Module__gateObj;
__extern __FAR__ const CT__bravo_math_RandGen_Module__gateObj bravo_math_RandGen_Module__gateObj__C;

/* Module__gatePrms */
typedef xdc_Ptr CT__bravo_math_RandGen_Module__gatePrms;
__extern __FAR__ const CT__bravo_math_RandGen_Module__gatePrms bravo_math_RandGen_Module__gatePrms__C;

/* Module__id */
typedef xdc_runtime_Types_ModuleId CT__bravo_math_RandGen_Module__id;
__extern __FAR__ const CT__bravo_math_RandGen_Module__id bravo_math_RandGen_Module__id__C;

/* Module__loggerDefined */
typedef xdc_Bool CT__bravo_math_RandGen_Module__loggerDefined;
__extern __FAR__ const CT__bravo_math_RandGen_Module__loggerDefined bravo_math_RandGen_Module__loggerDefined__C;

/* Module__loggerObj */
typedef xdc_Ptr CT__bravo_math_RandGen_Module__loggerObj;
__extern __FAR__ const CT__bravo_math_RandGen_Module__loggerObj bravo_math_RandGen_Module__loggerObj__C;

/* Module__loggerFxn4 */
typedef xdc_runtime_Types_LoggerFxn4 CT__bravo_math_RandGen_Module__loggerFxn4;
__extern __FAR__ const CT__bravo_math_RandGen_Module__loggerFxn4 bravo_math_RandGen_Module__loggerFxn4__C;

/* Module__loggerFxn8 */
typedef xdc_runtime_Types_LoggerFxn8 CT__bravo_math_RandGen_Module__loggerFxn8;
__extern __FAR__ const CT__bravo_math_RandGen_Module__loggerFxn8 bravo_math_RandGen_Module__loggerFxn8__C;

/* Module__startupDoneFxn */
typedef xdc_Bool (*CT__bravo_math_RandGen_Module__startupDoneFxn)(void);
__extern __FAR__ const CT__bravo_math_RandGen_Module__startupDoneFxn bravo_math_RandGen_Module__startupDoneFxn__C;

/* Object__count */
typedef xdc_Int CT__bravo_math_RandGen_Object__count;
__extern __FAR__ const CT__bravo_math_RandGen_Object__count bravo_math_RandGen_Object__count__C;

/* Object__heap */
typedef xdc_runtime_IHeap_Handle CT__bravo_math_RandGen_Object__heap;
__extern __FAR__ const CT__bravo_math_RandGen_Object__heap bravo_math_RandGen_Object__heap__C;

/* Object__sizeof */
typedef xdc_SizeT CT__bravo_math_RandGen_Object__sizeof;
__extern __FAR__ const CT__bravo_math_RandGen_Object__sizeof bravo_math_RandGen_Object__sizeof__C;

/* Object__table */
typedef xdc_Ptr CT__bravo_math_RandGen_Object__table;
__extern __FAR__ const CT__bravo_math_RandGen_Object__table bravo_math_RandGen_Object__table__C;


/*
 * ======== PER-INSTANCE TYPES ========
 */

/* Params */
struct bravo_math_RandGen_Params {
    size_t __size;
    const void* __self;
    void* __fxns;
    xdc_runtime_IInstance_Params* instance;
    xdc_Int16 range;
    xdc_UInt seed;
    xdc_runtime_IInstance_Params __iprms;
};

/* Struct */
struct bravo_math_RandGen_Struct {
    xdc_Int16 __f0;
    xdc_ULong __f1;
    xdc_runtime_Types_CordAddr __name;
};


/*
 * ======== FUNCTION DECLARATIONS ========
 */

/* Module_startup */
#define bravo_math_RandGen_Module_startup( state ) -1

/* Instance_init__F */
xdc__CODESECT(bravo_math_RandGen_Instance_init__F, "bravo_math_RandGen_Instance_init")
__extern void bravo_math_RandGen_Instance_init__F( bravo_math_RandGen_Object*, const bravo_math_RandGen_Params* );

/* Instance_init__R */
xdc__CODESECT(bravo_math_RandGen_Instance_init__R, "bravo_math_RandGen_Instance_init")
__extern void bravo_math_RandGen_Instance_init__R( bravo_math_RandGen_Object*, const bravo_math_RandGen_Params* );

/* Handle__label__S */
xdc__CODESECT(bravo_math_RandGen_Handle__label__S, "bravo_math_RandGen_Handle__label")
__extern xdc_runtime_Types_Label* bravo_math_RandGen_Handle__label__S( xdc_Ptr obj, xdc_runtime_Types_Label* lab );

/* Module__startupDone__S */
xdc__CODESECT(bravo_math_RandGen_Module__startupDone__S, "bravo_math_RandGen_Module__startupDone")
__extern xdc_Bool bravo_math_RandGen_Module__startupDone__S( void );

/* Object__create__S */
xdc__CODESECT(bravo_math_RandGen_Object__create__S, "bravo_math_RandGen_Object__create")
__extern xdc_Ptr bravo_math_RandGen_Object__create__S( xdc_Ptr __oa, xdc_SizeT __osz, xdc_Ptr __aa, const xdc_UChar* __pa, xdc_SizeT __psz, xdc_runtime_Error_Block* __eb );

/* Object__delete__S */
xdc__CODESECT(bravo_math_RandGen_Object__delete__S, "bravo_math_RandGen_Object__delete")
__extern xdc_Void bravo_math_RandGen_Object__delete__S( xdc_Ptr instp );

/* Object__destruct__S */
xdc__CODESECT(bravo_math_RandGen_Object__destruct__S, "bravo_math_RandGen_Object__destruct")
__extern xdc_Void bravo_math_RandGen_Object__destruct__S( xdc_Ptr objp );

/* Object__get__S */
xdc__CODESECT(bravo_math_RandGen_Object__get__S, "bravo_math_RandGen_Object__get")
__extern xdc_Ptr bravo_math_RandGen_Object__get__S( xdc_Ptr oarr, xdc_Int i );

/* Object__first__S */
xdc__CODESECT(bravo_math_RandGen_Object__first__S, "bravo_math_RandGen_Object__first")
__extern xdc_Ptr bravo_math_RandGen_Object__first__S( void );

/* Object__next__S */
xdc__CODESECT(bravo_math_RandGen_Object__next__S, "bravo_math_RandGen_Object__next")
__extern xdc_Ptr bravo_math_RandGen_Object__next__S( xdc_Ptr obj );

/* Params__init__S */
xdc__CODESECT(bravo_math_RandGen_Params__init__S, "bravo_math_RandGen_Params__init")
__extern xdc_Void bravo_math_RandGen_Params__init__S( xdc_Ptr dst, xdc_Ptr src, xdc_SizeT psz, xdc_SizeT isz );

/* Proxy__abstract__S */
xdc__CODESECT(bravo_math_RandGen_Proxy__abstract__S, "bravo_math_RandGen_Proxy__abstract")
__extern xdc_Bool bravo_math_RandGen_Proxy__abstract__S( void );

/* Proxy__delegate__S */
xdc__CODESECT(bravo_math_RandGen_Proxy__delegate__S, "bravo_math_RandGen_Proxy__delegate")
__extern xdc_Ptr bravo_math_RandGen_Proxy__delegate__S( void );

/* next__E */
#define bravo_math_RandGen_next bravo_math_RandGen_next__E
xdc__CODESECT(bravo_math_RandGen_next__E, "bravo_math_RandGen_next")
__extern xdc_Int16 bravo_math_RandGen_next__E( bravo_math_RandGen_Handle __inst );
xdc__CODESECT(bravo_math_RandGen_next__F, "bravo_math_RandGen_next")
__extern xdc_Int16 bravo_math_RandGen_next__F( bravo_math_RandGen_Object* __inst );
__extern xdc_Int16 bravo_math_RandGen_next__R( bravo_math_RandGen_Handle __inst );

/* nextn__E */
#define bravo_math_RandGen_nextn bravo_math_RandGen_nextn__E
xdc__CODESECT(bravo_math_RandGen_nextn__E, "bravo_math_RandGen_nextn")
__extern xdc_Void bravo_math_RandGen_nextn__E( bravo_math_RandGen_Handle __inst, xdc_Int16* buffer, xdc_Int count );
xdc__CODESECT(bravo_math_RandGen_nextn__F, "bravo_math_RandGen_nextn")
__extern xdc_Void bravo_math_RandGen_nextn__F( bravo_math_RandGen_Object* __inst, xdc_Int16* buffer, xdc_Int count );
__extern xdc_Void bravo_math_RandGen_nextn__R( bravo_math_RandGen_Handle __inst, xdc_Int16* buffer, xdc_Int count );


/*
 * ======== FUNCTION SELECTORS ========
 */

/* next_{FxnT,fxnP} */
typedef xdc_Int16 (*bravo_math_RandGen_next_FxnT)(void*);
static inline bravo_math_RandGen_next_FxnT bravo_math_RandGen_next_fxnP( void )
{
    return (bravo_math_RandGen_next_FxnT)bravo_math_RandGen_next; 
}

/* nextn_{FxnT,fxnP} */
typedef xdc_Void (*bravo_math_RandGen_nextn_FxnT)(void*, xdc_Int16*, xdc_Int);
static inline bravo_math_RandGen_nextn_FxnT bravo_math_RandGen_nextn_fxnP( void )
{
    return (bravo_math_RandGen_nextn_FxnT)bravo_math_RandGen_nextn; 
}


/*
 * ======== SYSTEM FUNCTIONS ========
 */

/* Module_startupDone */
#define bravo_math_RandGen_Module_startupDone() bravo_math_RandGen_Module__startupDone__S()

/* Object_heap */
#define bravo_math_RandGen_Object_heap() bravo_math_RandGen_Object__heap__C

/* Module_heap */
#define bravo_math_RandGen_Module_heap() bravo_math_RandGen_Object__heap__C

/* Module_id */
static inline CT__bravo_math_RandGen_Module__id bravo_math_RandGen_Module_id( void ) 
{
    return bravo_math_RandGen_Module__id__C;
}

/* Module_hasMask */
static inline xdc_Bool bravo_math_RandGen_Module_hasMask( void ) 
{
    return bravo_math_RandGen_Module__diagsMask__C != NULL;
}

/* Module_getMask */
static inline xdc_Bits16 bravo_math_RandGen_Module_getMask( void ) 
{
    return bravo_math_RandGen_Module__diagsMask__C != NULL ? *bravo_math_RandGen_Module__diagsMask__C : 0;
}

/* Module_setMask */
static inline xdc_Void bravo_math_RandGen_Module_setMask( xdc_Bits16 mask ) 
{
    if (bravo_math_RandGen_Module__diagsMask__C != NULL) *bravo_math_RandGen_Module__diagsMask__C = mask;
}

/* Params_init */
static inline void bravo_math_RandGen_Params_init( bravo_math_RandGen_Params* prms ) 
{
    if (prms) {
        bravo_math_RandGen_Params__init__S(prms, 0, sizeof(bravo_math_RandGen_Params), sizeof(xdc_runtime_IInstance_Params));
    }
}

/* Params_copy */
static inline void bravo_math_RandGen_Params_copy( bravo_math_RandGen_Params* dst, const bravo_math_RandGen_Params* src ) 
{
    if (dst) {
        bravo_math_RandGen_Params__init__S(dst, (xdc_Ptr)src, sizeof(bravo_math_RandGen_Params), sizeof(xdc_runtime_IInstance_Params));
    }
}

/* Object_count */
#define bravo_math_RandGen_Object_count() bravo_math_RandGen_Object__count__C

/* Object_sizeof */
#define bravo_math_RandGen_Object_sizeof() bravo_math_RandGen_Object__sizeof__C

/* Object_get */
static inline bravo_math_RandGen_Handle bravo_math_RandGen_Object_get( bravo_math_RandGen_Instance_State* oarr, int i ) 
{
    return (bravo_math_RandGen_Handle)bravo_math_RandGen_Object__get__S(oarr, i);
}

/* Object_first */
static inline bravo_math_RandGen_Handle bravo_math_RandGen_Object_first( void )
{
    return (bravo_math_RandGen_Handle)bravo_math_RandGen_Object__first__S();
}

/* Object_next */
static inline bravo_math_RandGen_Handle bravo_math_RandGen_Object_next( bravo_math_RandGen_Object* obj )
{
    return (bravo_math_RandGen_Handle)bravo_math_RandGen_Object__next__S(obj);
}

/* Handle_label */
static inline xdc_runtime_Types_Label* bravo_math_RandGen_Handle_label( bravo_math_RandGen_Handle inst, xdc_runtime_Types_Label* lab )
{
    return bravo_math_RandGen_Handle__label__S(inst, lab);
}

/* Handle_name */
static inline String bravo_math_RandGen_Handle_name( bravo_math_RandGen_Handle inst )
{
    xdc_runtime_Types_Label lab;
    return bravo_math_RandGen_Handle__label__S(inst, &lab)->iname;
}

/* create */
static inline bravo_math_RandGen_Handle bravo_math_RandGen_create( const bravo_math_RandGen_Params* __prms, xdc_runtime_Error_Block* __eb )
{
    return (bravo_math_RandGen_Handle)bravo_math_RandGen_Object__create__S(0, 0, 0, (const xdc_UChar*)__prms, sizeof(bravo_math_RandGen_Params), __eb);
}

/* construct */
static inline void bravo_math_RandGen_construct( bravo_math_RandGen_Struct* __obj, const bravo_math_RandGen_Params* __prms )
{
    bravo_math_RandGen_Object__create__S(__obj, sizeof (bravo_math_RandGen_Struct), 0, (const xdc_UChar*)__prms, sizeof(bravo_math_RandGen_Params), NULL);
}

/* delete */
static inline void bravo_math_RandGen_delete( bravo_math_RandGen_Handle* instp )
{
    bravo_math_RandGen_Object__delete__S(instp);
}

/* destruct */
static inline void bravo_math_RandGen_destruct( bravo_math_RandGen_Struct* obj )
{
    bravo_math_RandGen_Object__destruct__S(obj);
}

/* handle */
static inline bravo_math_RandGen_Handle bravo_math_RandGen_handle( bravo_math_RandGen_Struct* str )
{
    return (bravo_math_RandGen_Handle)str;
}

/* struct */
static inline bravo_math_RandGen_Struct* bravo_math_RandGen_struct( bravo_math_RandGen_Handle inst )
{
    return (bravo_math_RandGen_Struct*)inst;
}


/*
 * ======== EPILOGUE ========
 */

#ifdef bravo_math_RandGen__top__
#undef __nested__
#endif

#endif /* bravo_math_RandGen__include */


/*
 * ======== STATE STRUCTURES ========
 */

#if defined(__config__) || (!defined(__nested__) && defined(bravo_math_RandGen__internalaccess))

#ifndef bravo_math_RandGen__include_state
#define bravo_math_RandGen__include_state

/* Object */
struct bravo_math_RandGen_Object {
    xdc_Int16 range;
    xdc_ULong next;
};

#endif /* bravo_math_RandGen__include_state */

#endif


/*
 * ======== PREFIX ALIASES ========
 */

#if !defined(__nested__) && !defined(bravo_math_RandGen__nolocalnames)

/* module prefix */
#define RandGen_Instance bravo_math_RandGen_Instance
#define RandGen_Handle bravo_math_RandGen_Handle
#define RandGen_Module bravo_math_RandGen_Module
#define RandGen_Object bravo_math_RandGen_Object
#define RandGen_Struct bravo_math_RandGen_Struct
#define RandGen_MAXVALUE bravo_math_RandGen_MAXVALUE
#define RandGen_Instance_State bravo_math_RandGen_Instance_State
#define RandGen_Params bravo_math_RandGen_Params
#define RandGen_next bravo_math_RandGen_next
#define RandGen_next_fxnP bravo_math_RandGen_next_fxnP
#define RandGen_next_FxnT bravo_math_RandGen_next_FxnT
#define RandGen_nextn bravo_math_RandGen_nextn
#define RandGen_nextn_fxnP bravo_math_RandGen_nextn_fxnP
#define RandGen_nextn_FxnT bravo_math_RandGen_nextn_FxnT
#define RandGen_Module_name bravo_math_RandGen_Module_name
#define RandGen_Module_id bravo_math_RandGen_Module_id
#define RandGen_Module_startup bravo_math_RandGen_Module_startup
#define RandGen_Module_startupDone bravo_math_RandGen_Module_startupDone
#define RandGen_Module_hasMask bravo_math_RandGen_Module_hasMask
#define RandGen_Module_getMask bravo_math_RandGen_Module_getMask
#define RandGen_Module_setMask bravo_math_RandGen_Module_setMask
#define RandGen_Object_heap bravo_math_RandGen_Object_heap
#define RandGen_Module_heap bravo_math_RandGen_Module_heap
#define RandGen_construct bravo_math_RandGen_construct
#define RandGen_create bravo_math_RandGen_create
#define RandGen_handle bravo_math_RandGen_handle
#define RandGen_struct bravo_math_RandGen_struct
#define RandGen_Handle_label bravo_math_RandGen_Handle_label
#define RandGen_Handle_name bravo_math_RandGen_Handle_name
#define RandGen_Instance_init bravo_math_RandGen_Instance_init
#define RandGen_Object_count bravo_math_RandGen_Object_count
#define RandGen_Object_get bravo_math_RandGen_Object_get
#define RandGen_Object_first bravo_math_RandGen_Object_first
#define RandGen_Object_next bravo_math_RandGen_Object_next
#define RandGen_Object_sizeof bravo_math_RandGen_Object_sizeof
#define RandGen_Params_copy bravo_math_RandGen_Params_copy
#define RandGen_Params_init bravo_math_RandGen_Params_init
#define RandGen_delete bravo_math_RandGen_delete
#define RandGen_destruct bravo_math_RandGen_destruct

#endif
