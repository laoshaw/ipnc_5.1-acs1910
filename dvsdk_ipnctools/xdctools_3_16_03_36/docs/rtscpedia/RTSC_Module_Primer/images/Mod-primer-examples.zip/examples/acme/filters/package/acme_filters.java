/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-t35
 */
import java.util.*;
import org.mozilla.javascript.*;
import xdc.services.intern.xsr.*;
import xdc.services.spec.*;

public class acme_filters
{
    static final String VERS = "@(#) xdc-t35\n";

    static final Proto.Elm $$T_Bool = Proto.Elm.newBool();
    static final Proto.Elm $$T_Num = Proto.Elm.newNum();
    static final Proto.Elm $$T_Str = Proto.Elm.newStr();
    static final Proto.Elm $$T_Obj = Proto.Elm.newObj();

    static final Proto.Fxn $$T_Met = new Proto.Fxn(null, null, 0, -1, false);
    static final Proto.Map $$T_Map = new Proto.Map($$T_Obj);
    static final Proto.Arr $$T_Vec = new Proto.Arr($$T_Obj);

    static final XScriptO $$DEFAULT = Value.DEFAULT;
    static final Object $$UNDEF = Undefined.instance;

    static final Proto.Obj $$Package = (Proto.Obj)Global.get("$$Package");
    static final Proto.Obj $$Module = (Proto.Obj)Global.get("$$Module");
    static final Proto.Obj $$Instance = (Proto.Obj)Global.get("$$Instance");
    static final Proto.Obj $$Params = (Proto.Obj)Global.get("$$Params");

    static final Object $$objFldGet = Global.get("$$objFldGet");
    static final Object $$objFldSet = Global.get("$$objFldSet");
    static final Object $$proxyGet = Global.get("$$proxyGet");
    static final Object $$proxySet = Global.get("$$proxySet");
    static final Object $$delegGet = Global.get("$$delegGet");
    static final Object $$delegSet = Global.get("$$delegSet");

    Scriptable xdcO;
    Session ses;
    Value.Obj om;

    boolean isROV;
    boolean isCFG;

    Proto.Obj pkgP;
    Value.Obj pkgV;

    ArrayList<Object> imports = new ArrayList<Object>();
    ArrayList<Object> loggables = new ArrayList<Object>();
    ArrayList<Object> mcfgs = new ArrayList<Object>();
    ArrayList<Object> proxies = new ArrayList<Object>();
    ArrayList<Object> sizes = new ArrayList<Object>();
    ArrayList<Object> tdefs = new ArrayList<Object>();

    void $$IMPORTS()
    {
        Global.callFxn("loadPackage", xdcO, "xdc");
        Global.callFxn("loadPackage", xdcO, "xdc.corevers");
        Global.callFxn("loadPackage", xdcO, "xdc.runtime");
    }

    void $$OBJECTS()
    {
        pkgP = (Proto.Obj)om.bind("acme.filters.Package", new Proto.Obj());
        pkgV = (Value.Obj)om.bind("acme.filters", new Value.Obj("acme.filters", pkgP));
    }

    void Fir$$OBJECTS()
    {
        Proto.Obj po, spo;
        Value.Obj vo;

        po = (Proto.Obj)om.bind("acme.filters.Fir.Module", new Proto.Obj());
        vo = (Value.Obj)om.bind("acme.filters.Fir", new Value.Obj("acme.filters.Fir", po));
        pkgV.bind("Fir", vo);
        // decls 
        spo = (Proto.Obj)om.bind("acme.filters.Fir$$Instance_State", new Proto.Obj());
        om.bind("acme.filters.Fir.Instance_State", new Proto.Str(spo, false));
        // insts 
        Object insP = om.bind("acme.filters.Fir.Instance", new Proto.Obj());
        po = (Proto.Obj)om.bind("acme.filters.Fir$$Object", new Proto.Obj());
        Object objP = om.bind("acme.filters.Fir.Object", new Proto.Str(po, false));
        po = (Proto.Obj)om.bind("acme.filters.Fir$$Params", new Proto.Obj());
        om.bind("acme.filters.Fir.Params", new Proto.Str(po, false));
        om.bind("acme.filters.Fir.Handle", insP);
        if (isROV) {
            om.bind("acme.filters.Fir.Object", om.find("acme.filters.Fir.Instance_State"));
        }//isROV
    }

    void Fir$$CONSTS()
    {
        // module Fir
    }

    void Fir$$CREATES()
    {
        Proto.Fxn fxn;
        StringBuilder sb;

        if (isCFG) {
            sb = new StringBuilder();
            sb.append("acme$filters$Fir$$__initObject = function( inst ) {\n");
                sb.append("if (!this.$used) {\n");
                    sb.append("throw new Error(\"Function acme.filters.Fir.create() called before xdc.useModule('acme.filters.Fir')\");\n");
                sb.append("}\n");
                sb.append("var name = xdc.module('xdc.runtime.Text').defineRopeCord(inst.instance.name);\n");
                sb.append("inst.$object.$$bind('__name', name);\n");
                sb.append("this.instance$static$init.$fxn.apply(inst, [inst.$object, inst.$args.coeffs, inst.$args.coeffsLen, inst, inst.$module]);\n");
                sb.append("inst.$seal();\n");
            sb.append("};\n");
            Global.eval(sb.toString());
            fxn = (Proto.Fxn)om.bind("acme.filters.Fir$$create", new Proto.Fxn(om.find("acme.filters.Fir.Module"), om.find("acme.filters.Fir.Instance"), 3, 2, false));
                        fxn.addArg(0, "coeffs", new Proto.Arr(Proto.Elm.newCNum("(xdc_Int16)"), false), $$DEFAULT);
                        fxn.addArg(1, "coeffsLen", Proto.Elm.newCNum("(xdc_Int)"), $$UNDEF);
                        fxn.addArg(2, "__params", (Proto)om.find("acme.filters.Fir.Params"), Global.newObject());
            sb = new StringBuilder();
            sb.append("acme$filters$Fir$$create = function( coeffs, coeffsLen, __params ) {\n");
                sb.append("var __mod = xdc.om['acme.filters.Fir'];\n");
                sb.append("var __inst = xdc.om['acme.filters.Fir.Instance'].$$make();\n");
                sb.append("__inst.$$bind('$package', xdc.om['acme.filters']);\n");
                sb.append("__inst.$$bind('$index', __mod.$instances.length);\n");
                sb.append("__inst.$$bind('$category', 'Instance');\n");
                sb.append("__inst.$$bind('$args', {coeffs:coeffs, coeffsLen:coeffsLen});\n");
                sb.append("__inst.$$bind('$module', __mod);\n");
                sb.append("__mod.$instances.$add(__inst);\n");
                sb.append("__inst.$$bind('$object', new xdc.om['acme.filters.Fir'].Instance_State);\n");
                sb.append("for (__p in __params) __inst[__p] = __params[__p];\n");
                sb.append("var save = xdc.om.$curpkg;\n");
                sb.append("xdc.om.$$bind('$curpkg', __mod.$package.$name);\n");
                sb.append("__mod.instance$meta$init.$fxn.apply(__inst, [coeffs, coeffsLen]);\n");
                sb.append("xdc.om.$$bind('$curpkg', save);\n");
                sb.append("__inst.$$bless();\n");
                sb.append("if (xdc.om.$$phase >= 5) xdc.om['acme.filters.Fir'].__initObject(__inst);\n");
                sb.append("__inst.$$bind('$$phase', xdc.om.$$phase);\n");
                sb.append("return __inst;\n");
            sb.append("}\n");
            Global.eval(sb.toString());
        }//isCFG
        if (isCFG) {
            fxn = (Proto.Fxn)om.bind("acme.filters.Fir$$construct", new Proto.Fxn(om.find("acme.filters.Fir.Module"), null, 4, 2, false));
                        fxn.addArg(0, "__obj", (Proto)om.find("acme.filters.Fir$$Object"), null);
                        fxn.addArg(1, "coeffs", new Proto.Arr(Proto.Elm.newCNum("(xdc_Int16)"), false), $$DEFAULT);
                        fxn.addArg(2, "coeffsLen", Proto.Elm.newCNum("(xdc_Int)"), $$UNDEF);
                        fxn.addArg(3, "__params", (Proto)om.find("acme.filters.Fir.Params"), Global.newObject());
            sb = new StringBuilder();
            sb.append("acme$filters$Fir$$construct = function( __obj, coeffs, coeffsLen, __params ) {\n");
                sb.append("var __mod = xdc.om['acme.filters.Fir'];\n");
                sb.append("var __inst = __obj;\n");
                sb.append("__inst.$$bind('$args', {coeffs:coeffs, coeffsLen:coeffsLen});\n");
                sb.append("__inst.$$bind('$module', __mod);\n");
                sb.append("__mod.$objects.$add(__inst);\n");
                sb.append("__inst.$$bind('$object', xdc.om['acme.filters.Fir'].Instance_State.$$make(__inst.$$parent, __inst.$name));\n");
                sb.append("for (__p in __params) __inst[__p] = __params[__p];\n");
                sb.append("__inst.$$bless();\n");
                sb.append("if (xdc.om.$$phase >= 5) xdc.om['acme.filters.Fir'].__initObject(__inst);\n");
                sb.append("__inst.$$bind('$$phase', xdc.om.$$phase);\n");
                sb.append("return null;\n");
            sb.append("}\n");
            Global.eval(sb.toString());
        }//isCFG
    }

    void Fir$$FUNCTIONS()
    {
        Proto.Fxn fxn;

    }

    void Fir$$SIZES()
    {
        Proto.Str so;
        Object fxn;

        so = (Proto.Str)om.find("acme.filters.Fir.Instance_State");
        sizes.clear();
        sizes.add(Global.newArray("coeffs", "UPtr"));
        sizes.add(Global.newArray("coeffsLen", "TInt"));
        sizes.add(Global.newArray("frameLen", "TInt"));
        sizes.add(Global.newArray("history", "UPtr"));
        so.bind("$$sizes", Global.newArray(sizes.toArray()));
        fxn = Global.eval("function() { return $$sizeof(xdc.om['acme.filters.Fir.Instance_State']); }");
        so.bind("$sizeof", fxn);
        fxn = Global.eval("function() { return $$alignof(xdc.om['acme.filters.Fir.Instance_State']); }");
        so.bind("$alignof", fxn);
        fxn = Global.eval("function(fld) { return $$offsetof(xdc.om['acme.filters.Fir.Instance_State'], fld); }");
        so.bind("$offsetof", fxn);
    }

    void Fir$$TYPES()
    {
        Scriptable cap;
        Proto.Obj po;
        Proto.Str ps;
        Proto.Typedef pt;
        Object fxn;

        cap = (Scriptable)Global.callFxn("loadCapsule", xdcO, "acme/filters/Fir.xs");
        om.bind("acme.filters.Fir$$capsule", cap);
        po = (Proto.Obj)om.find("acme.filters.Fir.Module");
        po.init("acme.filters.Fir.Module", om.find("xdc.runtime.IModule.Module"));
                po.addFld("$hostonly", $$T_Num, 0, "r");
        if (isCFG) {
        }//isCFG
        if (isCFG) {
                        po.addFxn("create", (Proto.Fxn)om.find("acme.filters.Fir$$create"), Global.get("acme$filters$Fir$$create"));
                        po.addFxn("construct", (Proto.Fxn)om.find("acme.filters.Fir$$construct"), Global.get("acme$filters$Fir$$construct"));
        }//isCFG
                fxn = Global.get(cap, "module$use");
                if (fxn != null) om.bind("acme.filters.Fir$$module$use", true);
                if (fxn != null) po.addFxn("module$use", $$T_Met, fxn);
                fxn = Global.get(cap, "module$meta$init");
                if (fxn != null) om.bind("acme.filters.Fir$$module$meta$init", true);
                if (fxn != null) po.addFxn("module$meta$init", $$T_Met, fxn);
                fxn = Global.get(cap, "instance$meta$init");
                if (fxn != null) om.bind("acme.filters.Fir$$instance$meta$init", true);
                if (fxn != null) po.addFxn("instance$meta$init", $$T_Met, fxn);
                fxn = Global.get(cap, "module$static$init");
                if (fxn != null) om.bind("acme.filters.Fir$$module$static$init", true);
                if (fxn != null) po.addFxn("module$static$init", $$T_Met, fxn);
                fxn = Global.get(cap, "module$validate");
                if (fxn != null) om.bind("acme.filters.Fir$$module$validate", true);
                if (fxn != null) po.addFxn("module$validate", $$T_Met, fxn);
                fxn = Global.get(cap, "instance$static$init");
                if (fxn != null) om.bind("acme.filters.Fir$$instance$static$init", true);
                if (fxn != null) po.addFxn("instance$static$init", $$T_Met, fxn);
        po = (Proto.Obj)om.find("acme.filters.Fir.Instance");
        po.init("acme.filters.Fir.Instance", $$Instance);
                po.addFld("$hostonly", $$T_Num, 0, "r");
        if (isCFG) {
                        po.addFld("frameLen", Proto.Elm.newCNum("(xdc_Int)"), 64L, "w");
                        po.addFld("instance", (Proto)om.find("xdc.runtime.IInstance.Params"), $$UNDEF, "w");
        }//isCFG
        po = (Proto.Obj)om.find("acme.filters.Fir$$Params");
        po.init("acme.filters.Fir.Params", $$Params);
                po.addFld("$hostonly", $$T_Num, 0, "r");
        if (isCFG) {
                        po.addFld("frameLen", Proto.Elm.newCNum("(xdc_Int)"), 64L, "w");
                        po.addFld("instance", (Proto)om.find("xdc.runtime.IInstance.Params"), $$UNDEF, "w");
        }//isCFG
        po = (Proto.Obj)om.find("acme.filters.Fir$$Object");
        po.init("acme.filters.Fir.Object", om.find("acme.filters.Fir.Instance"));
        // struct Fir.Instance_State
        po = (Proto.Obj)om.find("acme.filters.Fir$$Instance_State");
        po.init("acme.filters.Fir.Instance_State", null);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("coeffs", new Proto.Arr(Proto.Elm.newCNum("(xdc_Int16)"), false), $$DEFAULT, "w");
                po.addFld("coeffsLen", Proto.Elm.newCNum("(xdc_Int)"), $$UNDEF, "w");
                po.addFld("frameLen", Proto.Elm.newCNum("(xdc_Int)"), $$UNDEF, "w");
                po.addFld("history", new Proto.Arr(Proto.Elm.newCNum("(xdc_Int16)"), false), $$DEFAULT, "w");
    }

    void Fir$$ROV()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.find("acme.filters.Fir");
        vo.bind("Instance_State$fetchDesc", Global.newObject("type", "acme.filters.Fir.Instance_State", "isScalar", false));
        po = (Proto.Obj)om.find("acme.filters.Fir$$Instance_State");
        po.bind("coeffs$fetchDesc", Global.newObject("type", "xdc.rov.support.ScalarStructs.S_Int16", "isScalar", true));
        po.bind("history$fetchDesc", Global.newObject("type", "xdc.rov.support.ScalarStructs.S_Int16", "isScalar", true));
    }

    void $$SINGLETONS()
    {
        pkgP.init("acme.filters.Package", (Proto.Obj)om.find("xdc.IPackage.Module"));
        pkgP.bind("$capsule", $$UNDEF);
        pkgV.init2(pkgP, "acme.filters", Value.DEFAULT, false);
        pkgV.bind("$name", "acme.filters");
        pkgV.bind("$category", "Package");
        pkgV.bind("$$qn", "acme.filters.");
        pkgV.bind("$vers", Global.newArray());
        Value.Map atmap = (Value.Map)pkgV.getv("$attr");
        atmap.seal("length");
        imports.clear();
        pkgV.bind("$imports", imports);
        StringBuilder sb = new StringBuilder();
        sb.append("var pkg = xdc.om['acme.filters'];\n");
        sb.append("if (pkg.$vers.length >= 3) {\n");
            sb.append("pkg.$vers.push(Packages.xdc.services.global.Vers.getDate(xdc.csd() + '/..'));\n");
        sb.append("}\n");
        sb.append("pkg.build.libraries = [\n");
            sb.append("'lib/acme.filters.a64P',\n");
            sb.append("'lib/acme.filters.a86GW',\n");
        sb.append("];\n");
        sb.append("pkg.build.libDesc = [\n");
            sb.append("['lib/acme.filters.a64P', {target: 'ti.targets.C64P'}],\n");
            sb.append("['lib/acme.filters.a86GW', {target: 'gnu.targets.Mingw'}],\n");
        sb.append("];\n");
        sb.append("if('suffix' in xdc.om['xdc.IPackage$$LibDesc']) {\n");
            sb.append("pkg.build.libDesc['lib/acme.filters.a64P'].suffix = '64P';\n");
            sb.append("pkg.build.libDesc['lib/acme.filters.a86GW'].suffix = '86GW';\n");
        sb.append("}\n");
        Global.eval(sb.toString());
    }

    void Fir$$SINGLETONS()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.find("acme.filters.Fir");
        po = (Proto.Obj)om.find("acme.filters.Fir.Module");
        vo.init2(po, "acme.filters.Fir", $$DEFAULT, false);
        vo.bind("Module", po);
        vo.bind("$category", "Module");
        vo.bind("$capsule", om.find("acme.filters.Fir$$capsule"));
        vo.bind("Instance", om.find("acme.filters.Fir.Instance"));
        vo.bind("Params", om.find("acme.filters.Fir.Params"));
        vo.bind("PARAMS", ((Proto.Str)om.find("acme.filters.Fir.Params")).newInstance());
        vo.bind("Handle", om.find("acme.filters.Fir.Handle"));
        vo.bind("$package", om.find("acme.filters"));
        tdefs.clear();
        proxies.clear();
        mcfgs.clear();
        mcfgs.add("Module__diagsEnabled");
        mcfgs.add("Module__diagsIncluded");
        mcfgs.add("Module__diagsMask");
        mcfgs.add("Module__gateObj");
        mcfgs.add("Module__gatePrms");
        mcfgs.add("Module__id");
        mcfgs.add("Module__loggerDefined");
        mcfgs.add("Module__loggerObj");
        mcfgs.add("Module__loggerFxn4");
        mcfgs.add("Module__loggerFxn8");
        mcfgs.add("Module__startupDoneFxn");
        mcfgs.add("Object__count");
        mcfgs.add("Object__heap");
        mcfgs.add("Object__sizeof");
        mcfgs.add("Object__table");
        vo.bind("Instance_State", om.find("acme.filters.Fir.Instance_State"));
        tdefs.add(om.find("acme.filters.Fir.Instance_State"));
        vo.bind("$$tdefs", Global.newArray(tdefs.toArray()));
        vo.bind("$$proxies", Global.newArray(proxies.toArray()));
        vo.bind("$$mcfgs", Global.newArray(mcfgs.toArray()));
        ((Value.Arr)pkgV.getv("$modules")).add(vo);
        ((Value.Arr)om.find("$modules")).add(vo);
        vo.bind("$$instflag", 1);
        vo.bind("$$iobjflag", 1);
        vo.bind("$$sizeflag", 1);
        vo.bind("$$dlgflag", 0);
        vo.bind("$$iflag", 0);
        vo.bind("$$romcfgs", "|");
        if (isCFG) {
            Proto.Str ps = (Proto.Str)vo.find("Module_State");
            if (ps != null) vo.bind("$object", ps.newInstance());
            vo.bind("$$meta_iobj", om.has("acme.filters.Fir$$instance$static$init", null) ? 1 : 0);
            vo.bind("__initObject", Global.get("acme$filters$Fir$$__initObject"));
        }//isCFG
        vo.bind("$$fxntab", Global.newArray("acme_filters_Fir_Handle__label__E", "acme_filters_Fir_Module__startupDone__E", "acme_filters_Fir_Object__create__E", "acme_filters_Fir_Object__delete__E", "acme_filters_Fir_Object__destruct__E", "acme_filters_Fir_Object__get__E", "acme_filters_Fir_Object__first__E", "acme_filters_Fir_Object__next__E", "acme_filters_Fir_Params__init__E", "acme_filters_Fir_Proxy__abstract__E", "acme_filters_Fir_Proxy__delegate__E", "acme_filters_Fir_apply__E"));
        vo.bind("$$logEvtCfgs", Global.newArray());
        vo.bind("$$errorDescCfgs", Global.newArray());
        vo.bind("$$assertDescCfgs", Global.newArray());
        Value.Map atmap = (Value.Map)vo.getv("$attr");
        atmap.setElem("", true);
        atmap.setElem("", true);
        atmap.seal("length");
        vo.bind("Object", om.find("acme.filters.Fir.Object"));
        vo.bind("MODULE_STARTUP$", 0);
        vo.bind("PROXY$", 0);
        loggables.clear();
        loggables.add(Global.newObject("name", "apply", "entry", "%p, %p, %p", "exit", ""));
        vo.bind("$$loggables", loggables.toArray());
        pkgV.bind("Fir", vo);
        ((Value.Arr)pkgV.getv("$unitNames")).add("Fir");
    }

    void $$INITIALIZATION()
    {
        Value.Obj vo;

        if (isCFG) {
            Object srcP = ((XScriptO)om.find("xdc.runtime.IInstance")).find("PARAMS");
            Scriptable dstP;

            dstP = (Scriptable)((XScriptO)om.find("acme.filters.Fir")).find("PARAMS");
            Global.put(dstP, "instance", srcP);
        }//isCFG
        Global.callFxn("module$meta$init", (Scriptable)om.find("acme.filters.Fir"));
        Global.callFxn("init", pkgV);
        ((Value.Obj)om.getv("acme.filters.Fir")).bless();
        ((Value.Arr)om.find("$packages")).add(pkgV);
    }

    public void exec( Scriptable xdcO, Session ses )
    {
        this.xdcO = xdcO;
        this.ses = ses;
        om = (Value.Obj)xdcO.get("om", null);

        Object o = om.geto("$name");
        String s = o instanceof String ? (String)o : null;
        isCFG = s != null && s.equals("cfg");
        isROV = s != null && s.equals("rov");

        $$IMPORTS();
        $$OBJECTS();
        Fir$$OBJECTS();
        Fir$$CONSTS();
        Fir$$CREATES();
        Fir$$FUNCTIONS();
        Fir$$SIZES();
        Fir$$TYPES();
        if (isROV) {
            Fir$$ROV();
        }//isROV
        $$SINGLETONS();
        Fir$$SINGLETONS();
        $$INITIALIZATION();
    }
}
