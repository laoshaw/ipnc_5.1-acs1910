/*
 *  ======== lesson5/prog.c ========
 */

#include <xdc/runtime/System.h>
 
int main()
{
    System_printf("Hello World\n");
    return 0;
}
