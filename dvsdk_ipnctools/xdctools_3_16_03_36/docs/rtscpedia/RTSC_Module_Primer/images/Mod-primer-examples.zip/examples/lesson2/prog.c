/*
 *  ======== lesson2/prog.c ========
 */

#include <acme/utils/Bench.h>
#include <xdc/runtime/System.h>
 
int main()
{
    Bench_begin("System_printf timing");
    System_printf("Hello World\n");
    Bench_end();
 
    return 0;
}
