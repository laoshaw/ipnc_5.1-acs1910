/*
 *  ======== acme/filters/test/FirTest1.c ========
 */

#include <acme/filters/Fir.h>
#include <acme/utils/Bench.h>
#include <xdc/runtime/System.h>
 
#define COEFFSLEN 4
#define FRAMELEN 20
 
static Int16 coeffs[COEFFSLEN] = {20000, 21000, 22000, -3000}; 
 
static Int16 inFrame[FRAMELEN] = {0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9};
static Int16 outFrame[FRAMELEN];
 
static Void printOut();
 
Int main()
{
    Fir_Handle fir;
    Fir_Params params;
 
    Fir_Params_init(&params);
    params.frameLen = FRAMELEN;
 
    fir = Fir_create(coeffs, COEFFSLEN, &params, NULL);  /* create filter */
    Bench_begin("\t--> Portable Baseline");              /* start benchmark */
    Fir_apply(fir, inFrame, outFrame);                   /* run filter */
    Bench_end();                                         /* stop and display timing */
    printOut();                                          /* display results */
    Fir_delete(&fir);                                    /* delete filter */
 
    return 0;
}
 
static Void printOut()
{
    Int i;
    String comma = "";
 
    System_printf("\toutFrame = {");
    for (i = 0; i < FRAMELEN; i++) {
        System_printf("%s%d", comma, outFrame[i]);
        comma = ",";
    }
    System_printf("}\n");
}
