#include <xdc/std.h>
#ifndef __config__
__FAR__ char local_targets__dummy__;
#define __xdc_PKGVERS 1, 0, 0
#define __xdc_PKGNAME local.targets
#define __xdc_PKGPREFIX local_targets_
#ifdef __xdc_bld_pkg_c__
#define __stringify(a) #a
#define __local_include(a) __stringify(a)
#include __local_include(__xdc_bld_pkg_c__)
#endif

#else

#endif
