#ifndef ti_sdo_codecs_dmvalmorp_ce__
#define ti_sdo_codecs_dmvalmorp_ce__

#endif /* ti_sdo_codecs_dmvalmorp_ce__ */ 
