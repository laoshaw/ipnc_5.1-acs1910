#include <xdc/std.h>
#ifndef __config__
__FAR__ char ti_sdo_codecs_dmvalmorp__dummy__;
#define __xdc_PKGVERS 1, 0, 0
#define __xdc_PKGNAME ti.sdo.codecs.dmvalmorp
#define __xdc_PKGPREFIX ti_sdo_codecs_dmvalmorp_
#ifdef __xdc_bld_pkg_c__
#define __stringify(a) #a
#define __local_include(a) __stringify(a)
#include __local_include(__xdc_bld_pkg_c__)
#endif

#else

#endif
